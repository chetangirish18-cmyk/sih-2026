import React, { useState } from 'react';
import { X, Smartphone, Wifi, QrCode, Camera, CheckCircle2, Copy, Zap } from 'lucide-react';

export default function MobileConnectModal({ hostIp = "172.20.129.131", onClose, onLaunchMobileCam }) {
  const [copied, setCopied] = useState(false);
  const mobileUrl = `http://${hostIp}:3000/mobile.html`;

  const copyUrl = () => {
    navigator.clipboard.writeText(mobileUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 font-sans">
      <div className="bg-[#0b1019] border border-cyan-500/50 rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="bg-slate-900 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-600 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Smartphone className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white tracking-wide">
                WIRELESS SMARTPHONE CAMERA LINK
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Connect your mobile phone as a live body camera feed
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 space-y-5 text-xs">
          {/* Wi-Fi Connection Banner */}
          <div className="bg-cyan-950/60 border border-cyan-800/80 p-3.5 rounded-xl text-cyan-200 flex items-start space-x-3">
            <Wifi className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <span className="font-bold text-white block">Step 1: Connect Phone to Wi-Fi</span>
              Ensure your smartphone is connected to the same Wi-Fi network as this computer.
            </div>
          </div>

          {/* QR Code / Direct Mobile URL */}
          <div className="bg-slate-900 p-5 rounded-xl border border-slate-800 text-center space-y-3">
            <div className="font-mono text-slate-300 font-semibold flex items-center justify-center gap-1">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>Step 2: Scan QR Code on Smartphone</span>
            </div>

            {/* Generated QR Code Box */}
            <div className="w-44 h-44 bg-white p-3 rounded-xl mx-auto flex items-center justify-center shadow-lg">
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=${encodeURIComponent(mobileUrl)}`}
                alt="Scan to pair mobile camera"
                className="w-full h-full object-contain"
              />
            </div>

            {/* Direct Mobile URL Box */}
            <div className="flex items-center space-x-2 max-w-sm mx-auto bg-slate-950 p-2.5 rounded-lg border border-slate-800 font-mono">
              <span className="truncate text-cyan-300 font-bold flex-1 text-left">{mobileUrl}</span>
              <button
                onClick={copyUrl}
                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded flex items-center gap-1 font-bold shrink-0"
              >
                {copied ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>

          {/* Direct Computer Camera Test */}
          <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">Testing on this computer (Webcam)?</span>
            <button
              onClick={onLaunchMobileCam}
              className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold rounded-lg shadow-lg flex items-center space-x-2"
            >
              <Camera className="w-4 h-4" />
              <span>Launch Live Camera</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
