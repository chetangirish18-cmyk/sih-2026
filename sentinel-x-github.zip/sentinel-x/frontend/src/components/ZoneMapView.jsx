import React from 'react';
import { MapPin, Navigation, Shield, Radio, Activity, ArrowRight } from 'lucide-react';

export default function ZoneMapView({ cameras, incident, onSelectEvent }) {
  const zones = [
    {
      id: "ZONE-A",
      name: "Outer Perimeter Gate",
      risk: "MEDIUM",
      coords: "28.5355° N, 77.3910° E",
      camera: "Aerial Recon Drone (Falcon-1)",
      camType: "Surveillance Drone",
      status: "ACTIVE_ALERT",
      color: "border-amber-500 bg-amber-950/30 text-amber-300"
    },
    {
      id: "ZONE-B",
      name: "North Courtyard",
      risk: "HIGH",
      coords: "28.5358° N, 77.3915° E",
      camera: "Tactical Scout Robot (Scout-X)",
      camType: "Tactical Robot",
      status: "ACTIVE_ALERT",
      color: "border-orange-500 bg-orange-950/30 text-orange-300"
    },
    {
      id: "ZONE-C",
      name: "Building Entrance",
      risk: "HIGH",
      coords: "28.5361° N, 77.3918° E",
      camera: "Assault Operator BodyCam",
      camType: "Body Camera",
      status: "ACTIVE_ALERT",
      color: "border-red-500 bg-red-950/30 text-red-300"
    },
    {
      id: "ZONE-D",
      name: "Restricted Command Core",
      risk: "CRITICAL",
      coords: "28.5364° N, 77.3922° E",
      camera: "Main Entrance CCTV",
      camType: "Stationary CCTV",
      status: "BREACH_CONFIRMED",
      color: "border-purple-500 bg-purple-950/40 text-purple-300"
    }
  ];

  return (
    <div className="space-y-6">
      {/* Zone Map Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="flex items-center gap-2">
          <Navigation className="w-5 h-5 text-cyan-400" />
          <h2 className="text-base font-bold text-white tracking-wide">
            Spatial Operational Zone Grid & Vector Trajectory Mapping
          </h2>
        </div>
        <p className="text-xs text-slate-400 mt-1">
          Topological mapping of physical surveillance zones and target vector progression across tactical feeds.
        </p>
      </div>

      {/* Grid Layout of Operational Zones */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {zones.map((z, idx) => {
          const matchedEvt = incident?.events?.find(e => e.zone_id === z.id);

          return (
            <div
              key={z.id}
              onClick={() => matchedEvt && onSelectEvent(matchedEvt)}
              className={`bg-slate-950 border-2 rounded-xl p-4 cursor-pointer transition-all duration-200 hover:scale-[1.02] shadow-xl relative ${z.color}`}
            >
              {/* Zone Header */}
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2 mb-3">
                <div className="flex items-center space-x-2">
                  <MapPin className="w-4 h-4 text-cyan-400" />
                  <span className="font-mono font-bold text-xs text-white">{z.id}</span>
                </div>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-slate-900 border border-slate-800">
                  {z.risk}
                </span>
              </div>

              {/* Zone Details */}
              <div className="space-y-2 text-xs font-mono">
                <div className="font-bold text-white text-sm tracking-wide">{z.name}</div>
                <div className="text-[11px] text-slate-400">{z.coords}</div>

                <div className="pt-2 border-t border-slate-800/60 text-[11px]">
                  <span className="text-slate-500">COVERAGE:</span>
                  <div className="text-cyan-300 font-semibold mt-0.5 truncate">{z.camera}</div>
                </div>

                {matchedEvt && (
                  <div className="mt-3 p-2 rounded bg-red-950/60 border border-red-800 text-[11px] text-red-300">
                    <div className="font-bold flex items-center gap-1">
                      <Radio className="w-3 h-3 text-red-400 animate-pulse" />
                      <span>TARGET TRAJECTORY STEP #{idx + 1}</span>
                    </div>
                    <div className="text-slate-200 mt-1 truncate">{matchedEvt.detection_label}</div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Trajectory Vector Summary Box */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4 font-mono text-xs">
        <div className="flex items-center space-x-2 text-slate-300">
          <Activity className="w-4 h-4 text-cyan-400" />
          <span>RECONSTRUCTED SPATIAL VECTOR:</span>
          <span className="text-cyan-300 font-bold">
            Zone A (Perimeter Gate) $\rightarrow$ Zone B (Courtyard) $\rightarrow$ Zone C (Entrance) $\rightarrow$ Zone D (Command Core)
          </span>
        </div>
        <div className="text-slate-400 text-right">
          Total Distance Vector: <span className="text-emerald-400 font-bold">142 Meters</span>
        </div>
      </div>
    </div>
  );
}
