import React, { useRef, useEffect } from 'react';

export default function SurveillanceCanvasStream({ cameraType, cameraName, zoneName, targetLabel, hasAlert }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let animationFrameId;
    let frame = 0;

    const render = () => {
      frame++;
      const w = canvas.width = 640;
      const h = canvas.height = 360;

      // 1. Base Surveillance Background
      if (cameraType === "Surveillance Drone") {
        // Aerial thermal / night vision style (dark greenish navy)
        ctx.fillStyle = '#061412';
        ctx.fillRect(0, 0, w, h);

        // Aerial Grid Lines
        ctx.strokeStyle = 'rgba(16, 185, 129, 0.15)';
        ctx.lineWidth = 1;
        for (let x = 0; x < w; x += 40) {
          ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
        }
        for (let y = 0; y < h; y += 40) {
          ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
        }

        // Moving Vehicle
        const vehicleX = (frame * 1.5) % (w + 100) - 50;
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(vehicleX, 180, 70, 35);
        ctx.fillStyle = '#10b981';
        ctx.fillRect(vehicleX + 10, 185, 20, 10);

        // Moving Subject (Person)
        const personX = vehicleX + 90;
        ctx.fillStyle = '#f43f5e';
        ctx.beginPath();
        ctx.arc(personX, 200, 6, 0, Math.PI * 2);
        ctx.fill();

        // Crosshair HUD
        ctx.strokeStyle = 'rgba(16, 185, 129, 0.4)';
        ctx.beginPath(); ctx.arc(w / 2, h / 2, 40, 0, Math.PI * 2); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(w / 2 - 50, h / 2); ctx.lineTo(w / 2 + 50, h / 2); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(w / 2, h / 2 - 50); ctx.lineTo(w / 2, h / 2 + 50); ctx.stroke();

      } else if (cameraType === "Tactical Robot") {
        // Ground Scout View (Courtyard with pillar)
        ctx.fillStyle = '#0b1329';
        ctx.fillRect(0, 0, w, h);

        // Ground Horizon & Pillars
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(0, 220, w, 140);

        // HVAC Pillar
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(320, 120, 50, 140);

        // Dropped Backpack (Thermal Highlight)
        const pulse = Math.sin(frame * 0.1) * 3;
        ctx.fillStyle = '#f59e0b';
        ctx.fillRect(330, 230 - pulse / 2, 30 + pulse, 20 + pulse);

        // Robot Telemetry Line
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.3)';
        ctx.setLineDash([4, 4]);
        ctx.beginPath(); ctx.moveTo(0, 280); ctx.lineTo(w, 280); ctx.stroke();
        ctx.setLineDash([]);

      } else if (cameraType === "Body Camera") {
        // BodyCam Corridor View (Slight camera motion bobbing)
        const bobY = Math.sin(frame * 0.15) * 4;
        ctx.fillStyle = '#0d1117';
        ctx.fillRect(0, 0, w, h);

        // Corridor Perspective Lines
        ctx.strokeStyle = '#1e293b';
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(180, 150 + bobY); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(w, 0); ctx.lineTo(460, 150 + bobY); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, h); ctx.lineTo(180, 230 + bobY); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(w, h); ctx.lineTo(460, 230 + bobY); ctx.stroke();

        // Sprinting Subject silhouette moving ahead
        const subX = 300 + Math.sin(frame * 0.08) * 40;
        ctx.fillStyle = '#e11d48';
        ctx.fillRect(subX, 160 + bobY, 24, 60);

      } else {
        // CCTV Restricted Core Door View
        ctx.fillStyle = '#090d16';
        ctx.fillRect(0, 0, w, h);

        // Security Door Hatch
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(400, 100, 140, 220);
        ctx.fillStyle = '#f43f5e';
        ctx.fillRect(410, 110, 120, 200); // Red Restricted Vault Access Door

        // Security Door Sensor LED
        const blink = (Math.floor(frame / 20) % 2 === 0);
        ctx.fillStyle = blink ? '#ef4444' : '#7f1d1d';
        ctx.beginPath(); ctx.arc(380, 140, 5, 0, Math.PI * 2); ctx.fill();
      }

      // 2. Camera Overlay Text & Scanline Effect
      ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
      ctx.font = '11px monospace';
      ctx.fillText(`REC ● [${cameraName}]`, 15, 25);
      ctx.fillText(`ZONE: ${zoneName}`, 15, 42);

      // Scanline Sweep Effect
      const scanY = (frame * 2) % h;
      ctx.fillStyle = 'rgba(6, 182, 212, 0.05)';
      ctx.fillRect(0, scanY, w, 4);

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [cameraType, cameraName, zoneName]);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full object-cover block"
    />
  );
}
