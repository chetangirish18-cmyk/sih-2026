import React, { useRef, useEffect, useState } from 'react';
import { Camera, Save, Play, Pause, Radio, Clock, Video, RefreshCw, Cpu, ShieldAlert } from 'lucide-react';
import * as tf from '@tensorflow/tfjs';
import * as cocoSsd from '@tensorflow-models/coco-ssd';
import * as blazeface from '@tensorflow-models/blazeface';

export default function DroidCamStreamer({ onEvidenceSaved }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const animRef = useRef(null);
  const timelapseFramesRef = useRef([]);
  const streamRef = useRef(null);

  const [isStreaming, setIsStreaming] = useState(false);
  const [devices, setDevices] = useState([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState('');
  const [error, setError] = useState('');

  const [timelapseList, setTimelapseList] = useState([]);
  const [savedClipsCount, setSavedClipsCount] = useState(1);
  const [isPlayingTimelapse, setIsPlayingTimelapse] = useState(false);
  const [currentFrameIdx, setCurrentFrameIdx] = useState(0);

  const [objectModel, setObjectModel] = useState(null);
  const [faceModel, setFaceModel] = useState(null);
  const [modelsLoaded, setModelsLoaded] = useState(false);
  const [modelError, setModelError] = useState('');
  const detectionsRef = useRef({ objects: [], faces: [] });

  // Threat alert state
  const [threatAlert, setThreatAlert] = useState(null); // { items, alertId, timestamp }
  const lastAlertTsRef = useRef(0); // client-side cooldown tracker
  const DANGEROUS_ITEMS = new Set([
    'knife', 'scissors', 'baseball bat',
    'bottle', 'sports ball', 'fork',
    // Future model support (not in COCO-SSD but ready if model is upgraded)
    'gun', 'pistol', 'rifle', 'grenade', 'fire', 'weapon', 'explosive',
  ]);

  // Enumerate all camera devices
  useEffect(() => {
    async function loadDevices() {
      try {
        // Request permission first so labels are visible
        const tempStream = await navigator.mediaDevices.getUserMedia({ video: true });
        tempStream.getTracks().forEach(t => t.stop());

        const all = await navigator.mediaDevices.enumerateDevices();
        const cams = all.filter(d => d.kind === 'videoinput');
        setDevices(cams);
        // Auto-select DroidCam if found, else first camera
        const droid = cams.find(d => d.label.toLowerCase().includes('droid'));
        const autoId = droid ? droid.deviceId : (cams[0]?.deviceId || '');
        setSelectedDeviceId(autoId);
      } catch (err) {
        setError('Camera permission denied. Please allow camera access in the browser and reload.');
      }
    }
    loadDevices();
  }, []);

  // Connect to selected camera
  const startCamera = async (deviceId) => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    setIsStreaming(false);
    setError('');

    try {
      const constraints = {
        video: deviceId
          ? { deviceId: { exact: deviceId }, width: { ideal: 1280 }, height: { ideal: 720 } }
          : { width: { ideal: 1280 }, height: { ideal: 720 } }
      };
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        setIsStreaming(true);
      }
    } catch (err) {
      setError(`Could not open camera: ${err.message}`);
    }
  };

  // Auto-start when selectedDeviceId is set
  useEffect(() => {
    if (selectedDeviceId) {
      startCamera(selectedDeviceId);
    }
    return () => {
      if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [selectedDeviceId]);

  // Load TensorFlow models
  useEffect(() => {
    let active = true;
    async function loadModels() {
      try {
        await tf.ready();
        const loadedCoco = await cocoSsd.load({ base: 'lite_mobilenet_v2' });
        const loadedFace = await blazeface.load();
        if (active) {
          setObjectModel(loadedCoco);
          setFaceModel(loadedFace);
          setModelsLoaded(true);
        }
      } catch (err) {
        console.error("TF Models load error:", err);
        if (active) setModelError("Failed to initialize AI models.");
      }
    }
    loadModels();
    return () => { active = false; };
  }, []);

  // Background detection loop
  useEffect(() => {
    if (!isStreaming || !modelsLoaded) return;
    let active = true;

    async function detectLoop() {
      while (active) {
        if (videoRef.current && videoRef.current.readyState >= 2) {
          try {
            const video = videoRef.current;
            const [objects, faces] = await Promise.all([
              objectModel ? objectModel.detect(video) : Promise.resolve([]),
              faceModel ? faceModel.estimateFaces(video, false) : Promise.resolve([])
            ]);
            if (active) {
              detectionsRef.current = { objects, faces };

              // ── Check for dangerous items ──────────────────────
              const dangerousFound = objects.filter(o => DANGEROUS_ITEMS.has(o.class));
              if (dangerousFound.length > 0) {
                const now = Date.now();
                // Client-side 30s cooldown to avoid spamming
                if (now - lastAlertTsRef.current > 30000) {
                  lastAlertTsRef.current = now;
                  const items = dangerousFound.map(o => o.class);
                  const scores = dangerousFound.map(o => o.score);
                  // Fire-and-forget API call
                  fetch('http://localhost:8000/api/droidcam-threat', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                      detected_items: items,
                      confidence_scores: scores,
                      zone: 'CCTV-05',
                      feed_name: 'DroidCam',
                    }),
                  })
                    .then(r => r.json())
                    .then(data => {
                      if (data.status === 'alerted') {
                        setThreatAlert({
                          items: data.items_detected,
                          alertId: data.alert_id,
                          timestamp: data.timestamp,
                          ntfy: data.ntfy_sent,
                          telegram: data.telegram_sent,
                        });
                        // Auto-dismiss after 10s
                        setTimeout(() => setThreatAlert(null), 10000);
                      }
                    })
                    .catch(err => console.warn('Threat alert API error:', err));
                }
              }
            }
          } catch (err) {
            console.warn("AI detection error:", err);
          }
        }
        await new Promise(r => setTimeout(r, 150));
      }
    }

    detectLoop();
    return () => { active = false; };
  }, [isStreaming, modelsLoaded, objectModel, faceModel]);

  // Canvas HUD overlay loop
  useEffect(() => {
    if (!isStreaming) return;
    let frameCounter = 0;
    const render = () => {
      frameCounter++;
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        canvas.width = 640;
        canvas.height = 360;
        ctx.clearRect(0, 0, 640, 360);
        ctx.fillStyle = 'rgba(255,255,255,0.85)';
        ctx.font = '11px monospace';
        ctx.fillText('DROIDCAM CCTV-05 \u25CF LIVE RECORDING', 15, 25);
        ctx.fillText('LOCATION: Zone C (Building Entrance)', 15, 40);

        // Draw real-time detection boxes & labels
        const video = videoRef.current;
        if (video) {
          const videoWidth = video.videoWidth || 640;
          const videoHeight = video.videoHeight || 360;
          const scaleX = canvas.width / videoWidth;
          const scaleY = canvas.height / videoHeight;

          const { objects, faces } = detectionsRef.current;

          // 1. Draw Object detections (Red for people, Yellow for objects)
          objects.forEach(obj => {
            const [x, y, w, h] = obj.bbox;
            const className = obj.class;
            const score = Math.round(obj.score * 100);
            const isPerson = className === 'person';
            const color = isPerson ? '#B54A3F' : '#eab308';

            ctx.strokeStyle = color;
            ctx.lineWidth = 2;
            ctx.strokeRect(x * scaleX, y * scaleY, w * scaleX, h * scaleY);

            ctx.fillStyle = color;
            ctx.font = 'bold 10px monospace';
            const label = `${className.toUpperCase()} ${score}%`;
            const textWidth = ctx.measureText(label).width;

            ctx.fillRect(x * scaleX, y * scaleY - 14, textWidth + 6, 14);
            ctx.fillStyle = '#000000';
            ctx.fillText(label, x * scaleX + 3, y * scaleY - 3);
          });

          // 2. Draw Face detections (Red dashed boxes)
          faces.forEach(face => {
            const [x1, y1] = face.topLeft;
            const [x2, y2] = face.bottomRight;
            const w = x2 - x1;
            const h = y2 - y1;
            const score = Math.round((face.probability[0] || 0.9) * 100);
            const color = '#B54A3F';

            ctx.strokeStyle = color;
            ctx.lineWidth = 1.5;
            ctx.setLineDash([4, 4]);
            ctx.strokeRect(x1 * scaleX, y1 * scaleY, w * scaleX, h * scaleY);
            ctx.setLineDash([]);

            ctx.fillStyle = color;
            ctx.font = 'bold 9px monospace';
            const label = `FACE ${score}%`;
            const textWidth = ctx.measureText(label).width;

            ctx.fillRect(x1 * scaleX, y1 * scaleY - 12, textWidth + 4, 12);
            ctx.fillStyle = '#000000';
            ctx.fillText(label, x1 * scaleX + 2, y1 * scaleY - 3);
          });
        }

        if (frameCounter % 40 === 0) {
          const snap = canvas.toDataURL('image/jpeg', 0.4);
          timelapseFramesRef.current.push({
            id: `tf-${Date.now()}`,
            timestamp: new Date().toISOString().substring(11, 19) + ' UTC',
            dataUrl: snap
          });
          if (timelapseFramesRef.current.length > 30) timelapseFramesRef.current.shift();
        }
      }
      animRef.current = requestAnimationFrame(render);
    };
    render();
    const syncInterval = setInterval(() => {
      setTimelapseList([...timelapseFramesRef.current]);
    }, 2000);
    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
      clearInterval(syncInterval);
    };
  }, [isStreaming]);

  // Timelapse autoplay
  useEffect(() => {
    if (!isPlayingTimelapse || timelapseList.length === 0) return;
    const interval = setInterval(() => {
      setCurrentFrameIdx(prev => (prev + 1) % timelapseList.length);
    }, 300);
    return () => clearInterval(interval);
  }, [isPlayingTimelapse, timelapseList.length]);

  const saveCurrentClip = () => {
    setSavedClipsCount(prev => prev + 1);
    if (onEvidenceSaved) {
      onEvidenceSaved({ id: `DROIDCAM-CLIP-${Date.now()}`, framesCount: timelapseList.length, timestamp: new Date().toISOString() });
    }
  };

  return (
    <div className="bg-[#13161a] border border-[#2a2e38] rounded-lg p-4 space-y-4 font-sans">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#2a2e38] pb-3">
        <div className="flex items-center space-x-2">
          <div className={`w-3 h-3 rounded-full ${isStreaming ? 'bg-[#3E8E7E] animate-pulse' : 'bg-slate-600'}`} />
          <h3 className="font-bold text-sm text-white tracking-wide flex items-center gap-2">
            DROIDCAM CCTV-05 (SMARTPHONE TACTICAL FEED)
            <span className={`text-[10px] px-2 py-0.5 rounded border bg-[#181b22] text-[#5B8DBF] border-[#2a2e38]`}>
              {isStreaming ? 'LIVE' : 'OFFLINE'}
            </span>
          </h3>
        </div>
        <div className="flex items-center space-x-2 text-xs">
          <span className="text-slate-400 font-sans">AUTO-SAVED CLIPS:</span>
          <span className="px-2 py-0.5 bg-[#3E8E7E]/20 text-[#3E8E7E] rounded border border-[#3E8E7E]/40 font-bold">{savedClipsCount} Saved</span>
        </div>
      </div>

      {/* Camera Selector */}
      <div className="flex items-center gap-3 text-xs font-sans">
        <Camera className="w-4 h-4 text-[#5B8DBF] shrink-0" />
        <select
          value={selectedDeviceId}
          onChange={e => setSelectedDeviceId(e.target.value)}
          className="flex-1 bg-[#13161a] border border-[#2a2e38] rounded-md px-3 py-2 text-white text-xs focus:outline-none focus:border-[#5B8DBF]"
        >
          {devices.length === 0 && <option value="">No cameras found — allow camera permission</option>}
          {devices.map((d, i) => (
            <option key={d.deviceId} value={d.deviceId}>
              {d.label || `Camera ${i + 1}`}
            </option>
          ))}
        </select>
        <button
          onClick={() => startCamera(selectedDeviceId)}
          className="px-3 py-2 bg-[#5B8DBF] hover:bg-[#48739f] text-white rounded-md font-bold flex items-center gap-1.5 transition-colors shrink-0"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Connect</span>
        </button>
      </div>

      {error && (
        <p className="text-xs font-sans text-[#B54A3F] bg-[#B54A3F]/10 border border-[#B54A3F] rounded-md px-3 py-2">{error}</p>
      )}

      {/* AI Model Status */}
      <div className="flex items-center gap-2 text-[10px] px-3 py-1.5 bg-[#13161a] rounded-md border border-[#2a2e38] text-slate-400">
        <Cpu className="w-3.5 h-3.5 text-[#5B8DBF]" />
        {modelError ? (
          <span className="text-red-400 font-bold">{modelError}</span>
        ) : !modelsLoaded ? (
          <span className="text-[#5B8DBF] animate-pulse font-bold">⏳ INITIALIZING COCO-SSD & BLAZEFACE AI MODELS...</span>
        ) : (
          <span className="text-[#3E8E7E] font-bold">🟢 AI TARGET TRACKING ACTIVE (PERSON: RED, OBJECTS: YELLOW)</span>
        )}
      </div>

      {/* Video Viewport */}
      <div className="relative aspect-video bg-black rounded-lg overflow-hidden border border-[#2a2e38]">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="absolute inset-0 w-full h-full object-cover"
        />
        <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />

        {!isStreaming && !error && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center space-y-2">
              <Video className="w-10 h-10 text-slate-600 mx-auto" />
              <p className="text-xs text-slate-500 font-sans">Select your DroidCam device above and click Connect</p>
            </div>
          </div>
        )}

        {isStreaming && (
          <div className="absolute top-3 left-3 bg-[#181b22]/90 backdrop-blur-md px-2.5 py-1 rounded border border-[#2a2e38] text-xs text-[#5B8DBF] flex items-center gap-2">
            <Radio className="w-3.5 h-3.5 text-[#B54A3F] animate-pulse" />
            <span>DroidCam Feed Active \u2022 Live</span>
          </div>
        )}

        {isStreaming && (
          <div className="absolute bottom-3 right-3 bg-[#181b22]/90 backdrop-blur-md px-3 py-1 rounded border border-[#2a2e38] text-xs text-[#3E8E7E] flex items-center gap-1.5 font-bold">
            <Save className="w-3.5 h-3.5" />
            <span>Auto-Recording Incident Keyframes</span>
          </div>
        )}

        {/* Dangerous item detected — flashing overlay */}
        {threatAlert && (
          <div className="absolute top-0 left-0 right-0 bg-[#B54A3F]/95 backdrop-blur-sm px-4 py-2.5 flex items-center justify-between text-white text-xs font-bold border-b-2 border-[#B54A3F] z-10">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 animate-pulse" />
              <span>⚠️ DANGEROUS ITEM: {threatAlert.items}</span>
            </div>
            <div className="flex items-center gap-3 text-[10px] font-normal">
              <span>ID: {threatAlert.alertId}</span>
              <span>ntfy: {threatAlert.ntfy ? '✅' : '❌'}</span>
              <span>TG: {threatAlert.telegram ? '✅' : '❌'}</span>
              <button onClick={() => setThreatAlert(null)} className="ml-2 px-2 py-0.5 bg-white/20 rounded hover:bg-white/30 transition-colors">✕</button>
            </div>
          </div>
        )}
      </div>

      {/* Threat Alert Strip (below video) */}
      {threatAlert && (
        <div className="bg-[#B54A3F]/10 border border-[#B54A3F] rounded-lg px-4 py-2.5 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-[#B54A3F] font-bold">
            <ShieldAlert className="w-4 h-4" />
            <span>ALERT DISPATCHED — {threatAlert.items} detected at {threatAlert.timestamp}</span>
          </div>
          <div className="flex items-center gap-2 text-slate-400">
            <span className="font-mono text-[10px]">{threatAlert.alertId}</span>
            <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${threatAlert.ntfy ? 'bg-[#3E8E7E]/20 text-[#3E8E7E]' : 'bg-[#B54A3F]/20 text-[#B54A3F]'}`}>
              ntfy {threatAlert.ntfy ? 'SENT' : 'FAIL'}
            </span>
          </div>
        </div>
      )}

      {/* Timelapse Player */}
      <div className="bg-[#13161a] p-4 rounded-lg border border-[#2a2e38] space-y-3 text-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2 text-[#5B8DBF] font-bold">
            <Clock className="w-4 h-4" />
            <span>CAUGHT INCIDENT TIMELAPSE SCRUBBER ({timelapseList.length} Keyframes)</span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setIsPlayingTimelapse(!isPlayingTimelapse)}
              className="px-3 py-1 bg-[#5B8DBF] hover:bg-[#48739f] text-white rounded font-bold flex items-center gap-1"
            >
              {isPlayingTimelapse ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
              <span>{isPlayingTimelapse ? 'Pause' : 'Play'} Timelapse</span>
            </button>
            <button
              onClick={saveCurrentClip}
              className="px-3 py-1 bg-[#3E8E7E] hover:bg-[#327366] text-white rounded font-bold flex items-center gap-1"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Evidence Clip</span>
            </button>
          </div>
        </div>
        {timelapseList.length > 0 && (
          <div className="space-y-2">
            <input
              type="range" min="0" max={Math.max(0, timelapseList.length - 1)}
              value={currentFrameIdx}
              onChange={e => { setIsPlayingTimelapse(false); setCurrentFrameIdx(parseInt(e.target.value)); }}
              className="w-full h-2 bg-[#2a2e38] rounded-md appearance-none cursor-pointer accent-[#5B8DBF]"
            />
            <div className="flex justify-between text-[11px] text-slate-400 font-sans">
              <span>Start: {timelapseList[0]?.timestamp}</span>
              <span className="text-[#5B8DBF] font-bold">Frame #{currentFrameIdx + 1}</span>
              <span>Latest: {timelapseList[timelapseList.length - 1]?.timestamp}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
