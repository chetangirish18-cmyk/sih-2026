import React from 'react';
import { Network, Clock, ShieldAlert, ArrowRight, Video, AlertCircle, FileCheck, CheckCircle2 } from 'lucide-react';

export default function IncidentTimeline({ incident, onSelectEvent, onOpenReport }) {
  if (!incident || !incident.events) return null;

  const events = incident.events;

  return (
    <div className="space-y-6">
      {/* Module 2 Header & Incident Summary */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-cyan-400 bg-cyan-950/80 px-2.5 py-1 rounded border border-cyan-800">
                MODULE 2: CONNECT
              </span>
              <h2 className="text-lg font-bold text-white tracking-wide">
                Cross-Source Incident Reconstitution & Graph Engine
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Links isolated observations across heterogeneous feeds based on time proximity ($\Delta t$) and topological zone adjacency.
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <div className="text-right font-mono">
              <div className="text-[11px] text-slate-400">OVERALL RISK SCORE</div>
              <div className="text-xl font-extrabold text-red-500 flex items-center justify-end gap-1">
                <ShieldAlert className="w-5 h-5" />
                <span>{incident.overall_risk_score}%</span>
              </div>
            </div>

            <button
              onClick={onOpenReport}
              className="px-4 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-bold text-xs rounded-lg shadow-lg shadow-blue-600/30 flex items-center space-x-2 transition-all"
            >
              <FileCheck className="w-4 h-4" />
              <span>Generate AI Incident Report</span>
            </button>
          </div>
        </div>

        {/* Tactical Incident Summary Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 text-xs font-mono">
          <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
            <span className="text-slate-400">INCIDENT ID:</span>
            <div className="text-cyan-400 font-bold mt-0.5">{incident.incident_id}</div>
          </div>
          <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
            <span className="text-slate-400">LINKED EVENTS:</span>
            <div className="text-white font-bold mt-0.5">{events.length} Camera Detections</div>
          </div>
          <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
            <span className="text-slate-400">TOTAL ELASED TIME:</span>
            <div className="text-amber-400 font-bold mt-0.5">40 Seconds</div>
          </div>
          <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
            <span className="text-slate-400">SPATIAL TRAJECTORY:</span>
            <div className="text-emerald-400 font-bold mt-0.5 truncate">Zone A $\rightarrow$ Zone D</div>
          </div>
        </div>
      </div>

      {/* Connected Event Chain Graph (Interactive Node Sequence) */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 shadow-xl relative overflow-hidden">
        <h3 className="text-sm font-bold text-slate-200 tracking-wider mb-6 flex items-center gap-2">
          <Network className="w-4 h-4 text-cyan-400" />
          <span>RECONSTRUCTED CROSS-SOURCE INCIDENT TIMELINE</span>
        </h3>

        {/* Timeline Node Chain Layout */}
        <div className="relative">
          {/* Horizontal Connecting Line (Desktop) */}
          <div className="hidden lg:block absolute top-1/2 left-8 right-8 h-1 bg-gradient-to-r from-blue-600 via-amber-500 to-red-600 transform -translate-y-1/2 rounded-full z-0 opacity-40" />

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 relative z-10">
            {events.map((evt, index) => {
              const prevEvt = index > 0 ? events[index - 1] : null;
              const deltaT = prevEvt ? evt.time_offset_sec - prevEvt.time_offset_sec : 0;

              return (
                <div key={evt.event_id} className="flex flex-col space-y-3">
                  {/* Delta-t Inter-Node Connector (If not first) */}
                  {index > 0 && (
                    <div className="flex items-center justify-center font-mono text-[11px] text-amber-400 bg-amber-950/40 border border-amber-800/60 rounded-full px-3 py-0.5 self-center shadow-md">
                      <Clock className="w-3 h-3 mr-1 text-amber-400" />
                      <span>+ {deltaT}s Time Delta</span>
                    </div>
                  )}

                  {/* Connected Event Card */}
                  <div
                    onClick={() => onSelectEvent(evt)}
                    className="bg-slate-950 border border-slate-800 hover:border-cyan-500/80 rounded-xl p-4 cursor-pointer transition-all duration-200 hover:shadow-2xl hover:shadow-cyan-500/10 group relative flex flex-col justify-between h-full"
                  >
                    <div>
                      {/* Step Indicator & Camera Source */}
                      <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 mb-3">
                        <div className="flex items-center space-x-2">
                          <span className="w-6 h-6 rounded-full bg-blue-900/80 text-blue-300 font-mono text-xs font-bold flex items-center justify-center border border-blue-700">
                            #{index + 1}
                          </span>
                          <span className="text-xs font-bold text-slate-200 group-hover:text-cyan-400 transition-colors">
                            {evt.camera_name}
                          </span>
                        </div>
                        <span className="text-[10px] font-mono px-2 py-0.5 bg-slate-900 text-slate-400 rounded border border-slate-800">
                          {evt.camera_type}
                        </span>
                      </div>

                      {/* Event Details */}
                      <div className="space-y-2 text-xs">
                        <div className="font-mono text-slate-400 flex items-center justify-between">
                          <span>LOCATION:</span>
                          <span className="text-amber-300 font-semibold">{evt.zone_name}</span>
                        </div>

                        <div className="font-semibold text-white group-hover:text-cyan-300 transition-colors leading-snug">
                          {evt.detection_label}
                        </div>

                        <p className="text-[11px] text-slate-400 line-clamp-2 italic">
                          "{evt.explanation?.what}"
                        </p>
                      </div>
                    </div>

                    {/* Bottom Metadata & Risk Badge */}
                    <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
                      <div className="flex items-center space-x-1 text-slate-400">
                        <Clock className="w-3 h-3 text-cyan-400" />
                        <span>{evt.timestamp.substring(11, 19)}</span>
                      </div>

                      <div className="flex items-center space-x-1.5">
                        <span className="text-[10px] px-2 py-0.5 rounded font-bold bg-red-950 text-red-400 border border-red-800">
                          RISK {evt.risk_score}%
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
