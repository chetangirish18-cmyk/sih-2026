import React, { useState, useEffect } from 'react';
import { X, FileText, Download, CheckCircle, ShieldAlert, Cpu, Sparkles, Printer } from 'lucide-react';
import { generateAIReport } from '../services/mockService';

export default function IncidentReportModal({ incidentId, onClose }) {
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadReport() {
      setLoading(true);
      const data = await generateAIReport(incidentId || "INC-2026-0828-01");
      setReport(data);
      setLoading(false);
    }
    loadReport();
  }, [incidentId]);

  const handleDownload = (format) => {
    if (!report) return;
    const jsonStr = JSON.stringify(report, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SENTINEL-X_Incident_Report_${report.incident_id}.${format.toLowerCase()}`;
    a.click();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#0b1019] border border-blue-500/50 rounded-2xl max-w-4xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="bg-slate-900 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
                  MODULE 3: REPORT
                </span>
                <h3 className="font-bold text-base text-white">
                  AI-Generated Evidence-Backed Incident Brief
                </h3>
              </div>
              <p className="text-xs text-slate-400 font-mono">
                Plain-Language LLM Synthesis • NSG Tactical Classification: TOP SECRET
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 space-y-6 overflow-y-auto font-sans flex-1">
          {loading ? (
            <div className="py-20 flex flex-col items-center justify-center text-center space-y-3">
              <Sparkles className="w-8 h-8 text-cyan-400 animate-spin" />
              <p className="text-sm font-mono text-cyan-300">
                SENTINEL-X AI Engine synthesizing connected multi-camera event sequence...
              </p>
            </div>
          ) : report ? (
            <div className="space-y-6">
              {/* Classification Banner */}
              <div className="bg-gradient-to-r from-red-950/80 via-slate-900 to-red-950/80 p-3 rounded-xl border border-red-800/80 text-center font-mono">
                <div className="text-xs font-extrabold tracking-widest text-red-400">
                  {report.classification}
                </div>
                <div className="text-[11px] text-slate-300 mt-0.5">
                  Generated at {report.generated_at} • Overall Risk: {report.overall_risk_score}% ({report.risk_level})
                </div>
              </div>

              {/* Executive Summary Section */}
              <div className="bg-slate-900/90 p-5 rounded-xl border border-slate-800 space-y-2">
                <h4 className="text-xs font-mono font-bold text-cyan-400 tracking-wider flex items-center gap-1.5">
                  <FileText className="w-4 h-4" />
                  <span>EXECUTIVE TACTICAL BRIEF</span>
                </h4>
                <p className="text-sm text-slate-200 leading-relaxed font-normal bg-slate-950 p-4 rounded-lg border border-slate-800">
                  {report.executive_summary}
                </p>
              </div>

              {/* Spatial Path */}
              <div className="bg-slate-900/90 p-4 rounded-xl border border-slate-800">
                <div className="text-xs font-mono font-bold text-amber-400 mb-1">
                  CONNECTED SPATIAL MOVEMENT TRAJECTORY
                </div>
                <div className="text-sm font-mono text-cyan-300 bg-slate-950 p-3 rounded-lg border border-slate-800 font-bold">
                  {report.spatial_movement_path}
                </div>
              </div>

              {/* Chronological Event Timeline Table */}
              <div className="bg-slate-900/90 p-5 rounded-xl border border-slate-800 space-y-3">
                <h4 className="text-xs font-mono font-bold text-slate-200 tracking-wider">
                  CHRONOLOGICAL EVIDENCE TIMELINE ({report.evidence_clips_count} LINKED CAMERAS)
                </h4>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-mono">
                    <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                      <tr>
                        <th className="p-2.5">STEP</th>
                        <th className="p-2.5">TIMESTAMP</th>
                        <th className="p-2.5">SOURCE CAMERA</th>
                        <th className="p-2.5">ZONE</th>
                        <th className="p-2.5">OBSERVATION</th>
                        <th className="p-2.5">EVIDENCE CLIP</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 text-slate-200">
                      {report.chronological_narrative.map((item) => (
                        <tr key={item.step} className="hover:bg-slate-800/40">
                          <td className="p-2.5 font-bold text-cyan-400">#{item.step}</td>
                          <td className="p-2.5 text-slate-300">{item.timestamp}</td>
                          <td className="p-2.5 text-white font-bold">{item.source}</td>
                          <td className="p-2.5 text-amber-300">{item.zone}</td>
                          <td className="p-2.5 max-w-xs">{item.observation}</td>
                          <td className="p-2.5 text-emerald-400 font-bold">{item.evidence_ref}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Investigator Action Recommendations Checklist */}
              <div className="bg-slate-900/90 p-5 rounded-xl border border-slate-800 space-y-3">
                <h4 className="text-xs font-mono font-bold text-emerald-400 tracking-wider flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4" />
                  <span>RECOMMENDED INVESTIGATOR ACTIONS</span>
                </h4>
                <ul className="space-y-2 text-xs text-slate-200">
                  {report.action_recommendations.map((rec, i) => (
                    <li key={i} className="flex items-start space-x-2 bg-slate-950 p-2.5 rounded-lg border border-slate-800 font-sans">
                      <span className="w-5 h-5 rounded-full bg-emerald-950 text-emerald-400 font-mono text-[10px] font-bold flex items-center justify-center border border-emerald-800 shrink-0 mt-0.5">
                        {i + 1}
                      </span>
                      <span>{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ) : null}
        </div>

        {/* Modal Footer with Export Buttons */}
        <div className="bg-slate-900 px-6 py-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="text-xs font-mono text-slate-400">
            Cut review time from <span className="text-red-400 line-through">hours</span> to <span className="text-emerald-400 font-bold">seconds</span>.
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => handleDownload('PDF')}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white font-mono text-xs rounded-lg transition-colors border border-slate-700"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export PDF</span>
            </button>
            <button
              onClick={() => handleDownload('MARKDOWN')}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white font-mono text-xs rounded-lg transition-colors border border-slate-700"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Markdown</span>
            </button>
            <button
              onClick={() => handleDownload('JSON')}
              className="flex items-center space-x-1.5 px-3.5 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white font-mono text-xs font-bold rounded-lg shadow-lg shadow-cyan-600/30 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export JSON Evidence</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
