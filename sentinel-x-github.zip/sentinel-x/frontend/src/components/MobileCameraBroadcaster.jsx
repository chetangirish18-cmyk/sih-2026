import React, { useRef, useEffect, useState } from 'react';
import { Camera, RefreshCw, Shield, Radio, CheckCircle2, AlertTriangle, ArrowLeft, Play, Upload } from 'lucide-react';

export default function MobileCameraBroadcaster({ onBackToDashboard, onFrameStream }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const fileInputRef = useRef(null);
  const [facingMode, setFacingMode] = useState('environment');
  const [isStreaming, setIsStreaming] = useState(false);
  const [hasUserStarted, setHasUserStarted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [fallbackImage, setFallbackImage] = useState(null);

  const startCameraStream = async () => {
    setHasUserStarted(true);
    setErrorMsg('');

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("HTTP connection restricted mediaDevices. Use Photo/Video Snapshot mode below.");
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: facingMode,
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        audio: false
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        setIsStreaming(true);
      }
    } catch (err) {
      console.warn("MediaDevices camera error:", err);
      setErrorMsg("Mobile browser restricted live video over HTTP. Please use Snapshot/Upload Mode below.");
    }
  };

  // Frame Capture loop to broadcast live video frames to command center
  useEffect(() => {
    if (!isStreaming) return;
    const interval = setInterval(() => {
      if (videoRef.current && canvasRef.current) {
        const video = videoRef.current;
        const canvas = canvasRef.current;
        if (video.readyState >= 2) {
          canvas.width = video.videoWidth || 640;
          canvas.height = video.videoHeight || 480;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const frameDataUrl = canvas.toDataURL('image/jpeg', 0.6);
          if (onFrameStream) {
            onFrameStream(frameDataUrl);
          }
        }
      }
    }, 200);

    return () => clearInterval(interval);
  }, [isStreaming, onFrameStream]);

  // Handle Snapshot / Photo capture fallback
  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const imgData = event.target.result;
        setFallbackImage(imgData);
        if (onFrameStream) {
          onFrameStream(imgData);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen bg-black text-slate-100 flex flex-col justify-between font-sans relative overflow-hidden">
      {/* HUD Header */}
      <header className="bg-slate-900 border-b border-slate-800 p-4 flex items-center justify-between z-20">
        <div className="flex items-center space-x-2">
          <button
            onClick={onBackToDashboard}
            className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="font-bold text-sm text-white tracking-wider flex items-center gap-2">
              WIRELESS MOBILE BODYCAM
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            </h1>
            <p className="text-[10px] text-slate-400 font-mono">SENTINEL-X Operational Feed • Zone C</p>
          </div>
        </div>

        {hasUserStarted && !errorMsg && (
          <button
            onClick={() => {
              setFacingMode(prev => prev === 'environment' ? 'user' : 'environment');
              startCameraStream();
            }}
            className="px-3 py-1.5 rounded-lg bg-cyan-950 border border-cyan-800 text-cyan-300 font-mono text-xs flex items-center space-x-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Flip</span>
          </button>
        )}
      </header>

      {/* Main Viewfinder / Touch Controls */}
      <div className="relative flex-1 bg-slate-950 flex flex-col items-center justify-center p-4">
        {!hasUserStarted ? (
          <div className="max-w-sm w-full bg-slate-900 border border-cyan-500/40 rounded-2xl p-6 text-center space-y-5 shadow-2xl">
            <div className="w-16 h-16 rounded-2xl bg-cyan-950 border border-cyan-700/60 flex items-center justify-center mx-auto shadow-lg shadow-cyan-500/20">
              <Camera className="w-8 h-8 text-cyan-400" />
            </div>

            <div>
              <h2 className="text-base font-bold text-white tracking-wide">
                START SMARTPHONE CAMERA
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Tap below to grant mobile camera permissions & broadcast live feed into SENTINEL-X.
              </p>
            </div>

            <button
              onClick={startCameraStream}
              className="w-full py-3.5 bg-gradient-to-r from-cyan-600 via-blue-600 to-emerald-600 text-white font-extrabold text-sm rounded-xl shadow-xl shadow-cyan-500/25 flex items-center justify-center space-x-2 transform active:scale-95 transition-transform"
            >
              <Play className="w-5 h-5 fill-current" />
              <span>START LIVE CAMERA STREAM</span>
            </button>

            {/* Snapshot Fallback Option */}
            <div className="pt-3 border-t border-slate-800 text-xs">
              <span className="text-slate-400 block mb-2">Or take a direct camera photo:</span>
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                capture="environment"
                onChange={handleFileUpload}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono rounded-lg border border-slate-700 flex items-center justify-center space-x-2"
              >
                <Upload className="w-4 h-4 text-cyan-400" />
                <span>Snap & Broadcast Photo</span>
              </button>
            </div>
          </div>
        ) : errorMsg ? (
          <div className="max-w-sm w-full bg-slate-900 border border-amber-800 rounded-2xl p-6 text-center space-y-4 shadow-2xl">
            <AlertTriangle className="w-10 h-10 text-amber-400 mx-auto" />
            <div className="text-sm font-bold text-amber-200">{errorMsg}</div>
            <p className="text-xs text-slate-300">
              Mobile browsers restrict live continuous video over HTTP connections. You can still stream live photos directly from your phone camera!
            </p>

            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              capture="environment"
              onChange={handleFileUpload}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full py-3 bg-gradient-to-r from-emerald-600 to-cyan-600 text-white font-bold rounded-xl shadow-lg flex items-center justify-center space-x-2"
            >
              <Camera className="w-5 h-5" />
              <span>Take & Stream Phone Photo</span>
            </button>
          </div>
        ) : (
          <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
            {fallbackImage ? (
              <img src={fallbackImage} alt="Phone Snapshot" className="w-full h-full object-contain" />
            ) : (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
            )}
            <canvas ref={canvasRef} className="hidden" />

            {/* YOLO Bounding Box Overlay */}
            <div className="absolute inset-0 pointer-events-none border-4 border-cyan-500/20">
              <div className="absolute top-1/3 left-1/4 w-1/2 h-1/3 border-2 border-red-500 bg-red-500/10 rounded animate-pulse">
                <div className="absolute -top-6 left-0 bg-red-600 text-white font-mono text-[10px] px-2 py-0.5 rounded font-bold flex items-center gap-1">
                  <span>SMARTPHONE BODYCAM TARGET</span>
                  <span className="bg-black/50 px-1 rounded">95%</span>
                </div>
              </div>
            </div>

            {/* Status Footer */}
            <div className="absolute bottom-6 inset-x-6 bg-slate-900/90 backdrop-blur-md p-3 rounded-xl border border-slate-800 text-xs font-mono text-cyan-300 flex items-center justify-between z-20">
              <div className="flex items-center space-x-2">
                <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
                <span>STREAMING TO COMMAND CENTER</span>
              </div>
              <span className="text-slate-400">720p LIVE</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
