import React, { useState } from 'react';
import { UserCheck, CheckCircle2, XCircle, ShieldAlert, Send, Bell } from 'lucide-react';

export default function OperatorFeedback({ incident, onFeedbackSubmitted }) {
  const [selectedAction, setSelectedAction] = useState('CONFIRM_THREAT');
  const [notes, setNotes] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [dispatching, setDispatching] = useState(false);
  const [dispatchResult, setDispatchResult] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitted(true);

    if (selectedAction === 'DISPATCH_QRT') {
      setDispatching(true);
      try {
        const res = await fetch('http://localhost:8000/api/qrt-dispatch', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ notes, zone: incident?.zone || 'Zone C' }),
        });
        const data = await res.json();
        setDispatchResult(data);
      } catch (err) {
        setDispatchResult({ error: 'Could not reach backend.' });
      } finally {
        setDispatching(false);
      }
    }

    if (onFeedbackSubmitted) {
      onFeedbackSubmitted({ action: selectedAction, notes });
    }
  };

  return (
    <div className="bg-[#181b22] border border-[#2a2e38] rounded-lg p-5 space-y-4">
      <div className="flex items-center space-x-2 border-b border-[#2a2e38] pb-3">
        <UserCheck className="w-5 h-5 text-[#5B8DBF]" />
        <h3 className="font-bold text-sm text-white tracking-wide font-sans">
          HUMAN OPERATOR FEEDBACK & TACTICAL RESPONSE PANEL
        </h3>
      </div>

      {submitted ? (
        <div className="bg-[#3E8E7E]/10 border border-[#3E8E7E]/40 p-4 rounded-lg text-center space-y-3 font-sans">
          <CheckCircle2 className="w-8 h-8 text-[#3E8E7E] mx-auto" />
          <div className="text-sm font-bold text-[#3E8E7E]">
            Operator Action Recorded: {selectedAction}
          </div>

          {selectedAction === 'DISPATCH_QRT' && (
            <div className="mt-2 space-y-2">
              {dispatching && (
                <div className="flex items-center justify-center gap-2 text-xs text-[#5B8DBF] animate-pulse">
                  <Bell className="w-4 h-4 animate-bounce" />
                  <span>Sending alert to your phone...</span>
                </div>
              )}
              {dispatchResult && !dispatchResult.error && (
                <div className="bg-[#13161a] border border-[#2a2e38] rounded-md px-4 py-3 text-xs font-mono space-y-1.5 text-left">
                  <div className="text-[#5B8DBF] font-bold border-b border-[#2a2e38] pb-1 mb-1">
                    🆔 {dispatchResult.incident_id}
                  </div>
                  <div className="text-slate-300">🗓 {dispatchResult.date}</div>
                  <div className="text-slate-300">⏰ {dispatchResult.timestamp}</div>
                  <div className="text-slate-300">🌐 {dispatchResult.coords}</div>
                  {dispatchResult.maps_url && (
                    <a
                      href={dispatchResult.maps_url}
                      target="_blank"
                      rel="noreferrer"
                      className="block text-[#5B8DBF] underline hover:text-[#7ba9db] font-sans font-semibold"
                    >
                      🗺 View Location on Maps →
                    </a>
                  )}
                  <div className="border-t border-[#2a2e38] pt-1 mt-1 space-y-1 font-sans">
                    <div className={dispatchResult.ntfy_sent ? 'text-[#3E8E7E]' : 'text-[#B54A3F]'}>
                      {dispatchResult.ntfy_sent ? '✅' : '❌'} Phone Popup Sent (ntfy.sh)
                    </div>
                    <div className={dispatchResult.telegram_sent ? 'text-[#3E8E7E]' : 'text-slate-500'}>
                      {dispatchResult.telegram_sent ? '✅' : '⚠️'} Telegram Alert Sent
                    </div>
                  </div>
                </div>
              )}
              {dispatchResult?.error && (
                <p className="text-xs text-[#B54A3F] font-mono">{dispatchResult.error}</p>
              )}
            </div>
          )}

          <p className="text-xs text-slate-400">
            Audit logging completed. Feedback appended to model improvement loop.
          </p>
          <button
            onClick={() => { setSubmitted(false); setDispatchResult(null); }}
            className="mt-2 text-xs text-[#5B8DBF] underline font-sans hover:text-[#7ba9db]"
          >
            Update Action
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4 text-xs font-sans">
          <div className="grid grid-cols-3 gap-3">
            <button
              type="button"
              onClick={() => setSelectedAction('CONFIRM_THREAT')}
              className={`p-3 rounded-lg border flex flex-col items-center space-y-1 transition-all ${
                selectedAction === 'CONFIRM_THREAT'
                  ? 'bg-[#B54A3F]/20 border-[#B54A3F] text-[#B54A3F] font-bold'
                  : 'bg-[#13161a] border-[#2a2e38] text-slate-400 hover:text-slate-200'
              }`}
            >
              <ShieldAlert className="w-5 h-5" />
              <span>Confirm Threat</span>
            </button>

            <button
              type="button"
              onClick={() => setSelectedAction('DISPATCH_QRT')}
              className={`p-3 rounded-lg border flex flex-col items-center space-y-1 transition-all ${
                selectedAction === 'DISPATCH_QRT'
                  ? 'bg-[#5B8DBF]/20 border-[#5B8DBF] text-[#5B8DBF] font-bold'
                  : 'bg-[#13161a] border-[#2a2e38] text-slate-400 hover:text-slate-200'
              }`}
            >
              <UserCheck className="w-5 h-5" />
              <span>Dispatch QRT Team</span>
            </button>

            <button
              type="button"
              onClick={() => setSelectedAction('MARK_FALSE_ALARM')}
              className={`p-3 rounded-lg border flex flex-col items-center space-y-1 transition-all ${
                selectedAction === 'MARK_FALSE_ALARM'
                  ? 'bg-[#2a2e38] border-slate-500 text-slate-200 font-bold'
                  : 'bg-[#13161a] border-[#2a2e38] text-slate-400 hover:text-slate-200'
              }`}
            >
              <XCircle className="w-5 h-5" />
              <span>Mark False Alarm</span>
            </button>
          </div>

          <div>
            <label className="block text-slate-400 mb-1 font-bold">TACTICAL OPERATOR NOTES:</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. QRT-1 dispatched to Zone D, Bomb disposal alerted for Zone B package..."
              className="w-full bg-[#13161a] border border-[#2a2e38] rounded-md p-2.5 text-white focus:outline-none focus:border-[#5B8DBF] text-xs font-sans"
            />
          </div>

          <button
            type="submit"
            className="w-full py-2.5 bg-[#3E8E7E] hover:bg-[#327366] text-white font-bold rounded-md flex items-center justify-center space-x-2 transition-all"
          >
            <Send className="w-4 h-4" />
            <span>Submit Operator Decision to Incident Log</span>
          </button>
        </form>
      )}
    </div>
  );
}
