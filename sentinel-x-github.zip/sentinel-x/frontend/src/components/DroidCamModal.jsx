import React, { useState, useEffect } from 'react';
import { X, Camera, Wifi, CheckCircle2, Video, Settings, Play } from 'lucide-react';

export default function DroidCamModal({ onClose, onConnect }) {
  const [devices, setDevices] = useState([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState('');
  const [ipAddress, setIpAddress] = useState('http://192.168.1.15:4747/video');

  useEffect(() => {
    async function loadDevices() {
      try {
        await navigator.mediaDevices.getUserMedia({ video: true });
        const devList = await navigator.mediaDevices.enumerateDevices();
        const videoDevs = devList.filter(d => d.kind === 'videoinput');
        setDevices(videoDevs);
        if (videoDevs.length > 0) {
          setSelectedDeviceId(videoDevs[0].deviceId);
        }
      } catch (err) {
        console.warn("Media devices enumeration error:", err);
      }
    }
    loadDevices();
  }, []);

  const handleConnect = () => {
    if (onConnect) {
      onConnect({
        deviceId: selectedDeviceId,
        ipUrl: ipAddress
      });
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 font-sans">
      <div className="bg-[#0b1019] border border-cyan-500/50 rounded-2xl max-w-md w-full shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="bg-slate-900 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-600 to-emerald-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Camera className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white tracking-wide">
                DROIDCAM CCTV INTEGRATION
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Connect DroidCam smartphone as operational CCTV
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 space-y-5 text-xs font-mono">
          {/* Method A: Select DroidCam Webcam Device */}
          <div className="space-y-2">
            <label className="block text-slate-300 font-bold">METHOD A: SELECT DROIDCAM WEBCAM DEVICE</label>
            <select
              value={selectedDeviceId}
              onChange={(e) => setSelectedDeviceId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-cyan-500 text-xs"
            >
              {devices.map((d, idx) => (
                <option key={d.deviceId || idx} value={d.deviceId}>
                  {d.label || `Camera Device #${idx + 1}`}
                </option>
              ))}
            </select>
            <p className="text-[11px] text-slate-400">
              Select DroidCam Source 2 / USB webcam device from list.
            </p>
          </div>

          {/* Method B: DroidCam Wi-Fi IP Stream */}
          <div className="space-y-2 pt-3 border-t border-slate-800">
            <label className="block text-slate-300 font-bold">METHOD B: DROIDCAM WI-FI STREAM URL</label>
            <input
              type="text"
              value={ipAddress}
              onChange={(e) => setIpAddress(e.target.value)}
              placeholder="http://192.168.1.XX:4747/video"
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-cyan-500 text-xs"
            />
            <p className="text-[11px] text-slate-400">
              Enter DroidCam Wi-Fi IP address shown in your phone app.
            </p>
          </div>

          <button
            onClick={handleConnect}
            className="w-full py-3 bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold rounded-xl shadow-lg shadow-emerald-500/20 flex items-center justify-center space-x-2 transition-all"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>Connect DroidCam as CCTV-05</span>
          </button>
        </div>
      </div>
    </div>
  );
}
