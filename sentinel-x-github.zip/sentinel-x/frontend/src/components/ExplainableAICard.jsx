import React from 'react';
import { X, ShieldAlert, CheckCircle2, Video, HelpCircle, MapPin, Clock, Cpu, Calculator, Info } from 'lucide-react';
import SurveillanceCanvasStream from './SurveillanceCanvasStream';

export default function ExplainableAICard({ event, onClose }) {
  if (!event) return null;

  const exp = event.explanation || {};
  const riskScore = event.risk_score || 75;
  const math = event.confidence_math || {
    p_object: 0.96,
    iou_score: 0.979,
    formula: "Confidence = P(Object) * IoU = 0.96 * 0.979 = 0.94"
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 font-sans">
      <div className="bg-[#0b1019] border border-cyan-500/40 rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="bg-slate-900 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-700/50 flex items-center justify-center">
              <Cpu className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white tracking-wide flex items-center gap-2">
                EXPLAINABLE AI MODULE (XAI)
                <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-red-950 text-red-400 border border-red-800">
                  RISK: {riskScore}%
                </span>
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Audit Trail ID: {event.event_id} • Source: {event.camera_name}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {/* Active Canvas Video Evidence Snippet */}
          <div className="relative aspect-video bg-black rounded-xl overflow-hidden border border-slate-800 group shadow-lg">
            <SurveillanceCanvasStream
              cameraType={event.camera_type}
              cameraName={event.camera_name}
              zoneName={event.zone_name}
              targetLabel={event.detection_label}
              hasAlert={true}
            />

            {/* Overlay Evidence Bounding Box */}
            <div
              className="absolute border-2 border-red-500 bg-red-500/20 rounded animate-pulse pointer-events-none"
              style={{
                left: `${event.bounding_box?.x || 20}%`,
                top: `${event.bounding_box?.y || 20}%`,
                width: `${event.bounding_box?.width || 30}%`,
                height: `${event.bounding_box?.height || 40}%`,
              }}
            >
              <div className="absolute -top-6 left-0 bg-red-600 text-white font-mono text-[10px] px-2 py-0.5 rounded font-bold">
                {event.detection_label} ({Math.round(event.confidence * 100)}%)
              </div>
            </div>

            <div className="absolute bottom-3 left-3 bg-slate-900/90 px-3 py-1 rounded-md border border-slate-700 text-xs font-mono text-cyan-300 flex items-center gap-2">
              <Video className="w-3.5 h-3.5 text-red-400 animate-pulse" />
              <span>Evidence Snippet: {exp.evidence_clip_seconds || "02:14:00 - 02:14:20"}</span>
            </div>
          </div>

          {/* Explicit Grounded AI Confidence Formula Breakdown Box */}
          <div className="bg-slate-900/90 p-4 rounded-xl border border-cyan-500/30 space-y-2 text-xs font-mono">
            <div className="flex items-center space-x-2 text-cyan-400 font-bold">
              <Calculator className="w-4 h-4" />
              <span>YOLOv8 MODEL CONFIDENCE FORMULA BREAKDOWN</span>
            </div>
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-slate-200 space-y-1">
              <div className="text-amber-300 font-bold">
                Formula: Confidence = P(Object Class) × IoU (Intersection Over Union)
              </div>
              <div className="text-slate-400 text-[11px]">
                • Base Class Detection Probability P(Object): <span className="text-white font-bold">{math.p_object}</span>
                <br />
                • Bounding Box IoU Overlap Score: <span className="text-white font-bold">{math.iou_score}</span>
                <br />
                • Output YOLO Confidence = {math.p_object} × {math.iou_score} = <span className="text-cyan-300 font-bold">{Math.round(event.confidence * 100)}%</span>
              </div>
            </div>
          </div>

          {/* 4 Core Explainability Questions Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            {/* 1. What Happened? */}
            <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
              <div className="text-cyan-400 font-mono font-bold mb-1 flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4 text-cyan-400" />
                <span>1. WHAT HAPPENED?</span>
              </div>
              <p className="text-slate-200 leading-relaxed font-medium">
                {exp.what || event.detection_label}
              </p>
            </div>

            {/* 2. Where? */}
            <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
              <div className="text-amber-400 font-mono font-bold mb-1 flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-amber-400" />
                <span>2. WHERE?</span>
              </div>
              <p className="text-slate-200 leading-relaxed font-medium">
                {exp.where || `${event.zone_name} (${event.zone_id})`}
              </p>
            </div>

            {/* 3. When? */}
            <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
              <div className="text-emerald-400 font-mono font-bold mb-1 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-emerald-400" />
                <span>3. WHEN?</span>
              </div>
              <p className="text-slate-200 leading-relaxed font-medium">
                {exp.when || event.timestamp}
              </p>
            </div>

            {/* 4. Why Considered Abnormal? */}
            <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
              <div className="text-red-400 font-mono font-bold mb-1 flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-red-400" />
                <span>4. WHY CONSIDERED ABNORMAL?</span>
              </div>
              <p className="text-slate-200 leading-relaxed font-medium">
                {exp.why_abnormal || "Observed pattern deviates from standard operational baselines."}
              </p>
            </div>
          </div>

          {/* Risk Score Calculation Formula */}
          <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 flex items-center justify-between font-mono text-xs">
            <div>
              <span className="text-slate-400">YOLO MODEL CONFIDENCE:</span>
              <div className="text-white font-bold text-sm mt-0.5">
                {Math.round(event.confidence * 100)}% Match
              </div>
            </div>

            <div className="text-right">
              <span className="text-slate-400">CALCULATED RISK SCORE:</span>
              <div className="text-red-500 font-extrabold text-base mt-0.5">
                {riskScore}% (HIGH RISK)
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-900 px-6 py-3 border-t border-slate-800 flex justify-end font-mono text-xs">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-lg transition-colors"
          >
            Close Inspector
          </button>
        </div>
      </div>
    </div>
  );
}
