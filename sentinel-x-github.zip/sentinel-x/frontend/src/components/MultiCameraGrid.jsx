import React, { useState } from 'react';
import { Camera, Eye, Zap, ShieldAlert, Cpu, Maximize2, Activity } from 'lucide-react';
import SurveillanceCanvasStream from './SurveillanceCanvasStream';

export default function MultiCameraGrid({ cameras, incident, onSelectEvent }) {
  const [showOverlay, setShowOverlay] = useState(true);
  const [lowLightMode, setLowLightMode] = useState(false);
  const [selectedCamFilter, setSelectedCamFilter] = useState('ALL');

  const filteredCameras = selectedCamFilter === 'ALL'
    ? cameras
    : cameras.filter(c => c.type.toLowerCase().includes(selectedCamFilter.toLowerCase()));

  const getEventForCam = (camId) => {
    return incident?.events?.find(e => e.camera_id === camId);
  };

  return (
    <div className="space-y-4 font-sans">
      {/* Module 1 Header & Controls */}
      <div className="bg-[#05080c] border border-[#aa7c11]/30 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold text-[#d4af37] bg-[#111a2e] px-2.5 py-1 rounded border border-[#d4af37]/30">
              TACTICAL DETECT SYSTEM
            </span>
            <h2 className="text-base font-bold text-white tracking-wide uppercase">
              Heterogeneous Multi-Source Video Analytics Pipeline
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Pretrained YOLOv8 / PyTorch stream ingestion, object persistence tracking & anomaly classification.
          </p>
        </div>

        {/* HUD Controls */}
        <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
          <button
            onClick={() => setShowOverlay(!showOverlay)}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border font-medium transition-all ${
              showOverlay
                ? 'bg-[#111a2e] border-[#d4af37] text-[#d4af37] shadow-md shadow-[#d4af37]/5'
                : 'bg-slate-900 border-slate-800 text-slate-500'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>YOLO Bounding Boxes: {showOverlay ? 'ON' : 'OFF'}</span>
          </button>

          <button
            onClick={() => setLowLightMode(!lowLightMode)}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border font-medium transition-all ${
              lowLightMode
                ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300'
                : 'bg-slate-900 border-slate-800 text-slate-500'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>IR / Night Enhancer</span>
          </button>

          {/* Filter Pills */}
          <div className="flex items-center bg-[#0a0e17] p-1 rounded-lg border border-[#aa7c11]/20">
            {['ALL', 'Drone', 'Robot', 'Body', 'CCTV'].map(filter => (
              <button
                key={filter}
                onClick={() => setSelectedCamFilter(filter)}
                className={`px-2.5 py-1 rounded text-[11px] font-mono transition-all ${
                  selectedCamFilter === filter
                    ? 'bg-[#aa7c11] text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Multi-Camera 2x2 Player Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredCameras.map((cam) => {
          const matchedEvent = getEventForCam(cam.id);
          const hasActiveAlert = !!matchedEvent;

          return (
            <div
              key={cam.id}
              className={`relative bg-slate-950 border rounded-xl overflow-hidden shadow-xl transition-all duration-200 group ${
                hasActiveAlert
                  ? 'border-red-600/80 ring-1 ring-red-500/30'
                  : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Active Animated Surveillance Canvas Video Viewport */}
              <div className="relative aspect-video bg-black overflow-hidden flex items-center justify-center">
                <SurveillanceCanvasStream
                  cameraType={cam.type}
                  cameraName={cam.name}
                  zoneName={cam.zone_name}
                  targetLabel={matchedEvent?.detection_label}
                  hasAlert={hasActiveAlert}
                />

                {/* YOLO Bounding Box Overlay */}
                {showOverlay && matchedEvent && (
                  <div
                    className="absolute border-2 border-red-500 bg-red-500/10 rounded transition-all animate-pulse pointer-events-none"
                    style={{
                      left: `${matchedEvent.bounding_box.x}%`,
                      top: `${matchedEvent.bounding_box.y}%`,
                      width: `${matchedEvent.bounding_box.width}%`,
                      height: `${matchedEvent.bounding_box.height}%`,
                    }}
                  >
                    {/* Bounding Box Label Tag */}
                    <div className="absolute -top-7 left-0 bg-red-600 text-white font-mono text-[10px] font-bold px-2 py-0.5 rounded shadow-lg flex items-center gap-1 whitespace-nowrap">
                      <span>{matchedEvent.detection_label}</span>
                      <span className="bg-black/50 px-1 rounded font-extrabold text-amber-300">
                        {Math.round(matchedEvent.confidence * 100)}%
                      </span>
                    </div>
                    {/* Reticles */}
                    <div className="absolute top-0 left-0 w-2 h-2 border-t-2 border-l-2 border-yellow-400" />
                    <div className="absolute top-0 right-0 w-2 h-2 border-t-2 border-r-2 border-yellow-400" />
                    <div className="absolute bottom-0 left-0 w-2 h-2 border-b-2 border-l-2 border-yellow-400" />
                    <div className="absolute bottom-0 right-0 w-2 h-2 border-b-2 border-r-2 border-yellow-400" />
                  </div>
                )}

                {/* Camera Name HUD Badge (Top Left) */}
                <div className="absolute top-3 left-3 bg-slate-900/90 backdrop-blur-md px-2.5 py-1 rounded-md border border-slate-700/80 text-[11px] font-mono text-slate-200 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  <span className="font-bold text-white">{cam.name}</span>
                </div>

                {/* Camera Telemetry Metadata (Top Right) */}
                <div className="absolute top-3 right-3 bg-slate-900/90 backdrop-blur-md px-2.5 py-1 rounded-md border border-slate-700/80 text-[10px] font-mono text-cyan-300">
                  {cam.battery && `BAT: ${cam.battery}`}
                  {cam.altitude && ` • ALT: ${cam.altitude}`}
                  {cam.signal_strength && ` • SIG: ${cam.signal_strength}`}
                  {cam.fps && ` • ${cam.fps} FPS`}
                </div>

                {/* Bottom Overlay Action Bar */}
                <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent p-3 flex items-end justify-between">
                  <div>
                    <div className="flex items-center gap-2 text-xs font-mono">
                      <span className="text-slate-400">ZONE:</span>
                      <span className="text-amber-300 font-semibold">{cam.zone_name}</span>
                    </div>
                    {matchedEvent && (
                      <div className="text-[11px] text-red-400 font-mono mt-0.5 flex items-center gap-1 font-bold">
                        <ShieldAlert className="w-3.5 h-3.5" />
                        <span>ALERT: {matchedEvent.detection_label}</span>
                      </div>
                    )}
                  </div>

                  {matchedEvent && (
                    <button
                      onClick={() => onSelectEvent(matchedEvent)}
                      className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white font-mono text-xs font-bold rounded-lg shadow-lg shadow-red-600/30 flex items-center space-x-1.5 transition-all transform active:scale-95"
                    >
                      <Cpu className="w-3.5 h-3.5" />
                      <span>Inspect AI Evidence</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
