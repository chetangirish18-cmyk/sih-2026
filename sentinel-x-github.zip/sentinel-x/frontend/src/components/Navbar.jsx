import React from 'react';

export default function Navbar() {
  return (
    <header className="bg-[#05080c] border-b-2 border-[#aa7c11] text-slate-100 px-6 py-0 sticky top-0 z-50 shadow-2xl">
      <div className="max-w-[1600px] mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-0 h-[80px]">
        
        {/* Authoritative NSG Logo & Government Branding */}
        <div className="flex items-center space-x-4 py-3 shrink-0">
          <img 
            src="/nsg-logo.png" 
            alt="NSG Logo" 
            className="w-14 h-14 object-contain filter drop-shadow-[0_0_8px_rgba(212,175,55,0.4)]"
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-serif font-extrabold text-lg md:text-xl tracking-wider text-white">
                NATIONAL SECURITY GUARD <span className="text-[#d4af37] font-sans font-bold text-sm bg-[#111a2e] px-2 py-0.5 rounded border border-[#d4af37]/30 ml-1">NSG</span>
              </h1>
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center sm:gap-2.5 mt-0.5 text-xs">
              <span className="text-[#d4af37] font-semibold tracking-widest font-mono text-[10px]">
                “SARVATRA SARVOTTAM SURAKSHA”
              </span>
              <span className="hidden sm:inline text-slate-500">•</span>
              <span className="text-slate-400 font-medium tracking-wide">
                GOVERNMENT OF INDIA • MINISTRY OF HOME AFFAIRS
              </span>
            </div>
          </div>
        </div>

        {/* Tactical Image Banner on the Right */}
        <div className="md:ml-4 flex-1 hidden md:block h-full relative">
          <img 
            src="/nsg-banner.png" 
            alt="NSG Banner" 
            className="absolute right-0 top-0 bottom-0 h-full max-w-full object-cover border-l border-[#aa7c11]/30"
          />
        </div>

      </div>
    </header>
  );
}
