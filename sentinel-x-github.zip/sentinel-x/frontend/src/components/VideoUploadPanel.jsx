import React, { useState, useRef } from 'react';
import { Upload, Video, Loader2, CheckCircle2, ShieldAlert, AlertTriangle, Radio, Film } from 'lucide-react';

const API = 'http://localhost:8000';

const SLOT_CONFIGS = [
  { slotId: 0, label: 'SCREEN 1', defaultSource: 'Drone-01', zone: 'ZONE-A' },
  { slotId: 1, label: 'SCREEN 2', defaultSource: 'Robot-02', zone: 'ZONE-B' },
  { slotId: 2, label: 'SCREEN 3', defaultSource: 'CCTV-02', zone: 'ZONE-C' },
];

export default function VideoUploadPanel() {
  const [slots, setSlots] = useState([
    { slotId: 0, status: 'idle', file: null, result: null, error: null },
    { slotId: 1, status: 'idle', file: null, result: null, error: null },
    { slotId: 2, status: 'idle', file: null, result: null, error: null },
  ]);

  const fileInputRefMaster = useRef(null);
  const slotInputRefs = [useRef(null), useRef(null), useRef(null)];

  const getLocation = () => new Promise((resolve) => {
    if (!navigator.geolocation) { resolve({ lat: null, lon: null }); return; }
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: pos.coords.latitude, lon: pos.coords.longitude }),
      () => resolve({ lat: null, lon: null })
    );
  });

  const pollJob = async (slotId, serverJobId) => {
    const poll = async () => {
      try {
        const res = await fetch(`${API}/api/detect/job/${serverJobId}`);
        const data = await res.json();
        if (data.status === 'done') {
          setSlots(prev => prev.map((s, idx) => idx === slotId ? { ...s, status: 'done', result: data.result } : s));
          return;
        }
        if (data.status === 'error') {
          setSlots(prev => prev.map((s, idx) => idx === slotId ? { ...s, status: 'error', error: data.error } : s));
          return;
        }
        setTimeout(poll, 1500);
      } catch (e) { setTimeout(poll, 2000); }
    };
    poll();
  };

  const uploadToSlot = async (file, slotId) => {
    const config = SLOT_CONFIGS[slotId];
    const sourceId = config.defaultSource;
    const { lat, lon } = await getLocation();
    setSlots(prev => prev.map((s, idx) => idx === slotId ? { ...s, status: 'uploading', file, result: null, error: null } : s));
    try {
      const form = new FormData();
      form.append('file', file);
      let url = `${API}/api/detect/upload?source_id=${encodeURIComponent(sourceId)}`;
      if (lat !== null && lon !== null) url += `&lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}`;
      const res = await fetch(url, { method: 'POST', body: form });
      if (!res.ok) throw new Error(`Upload failed: ${res.status}`);
      const data = await res.json();
      setSlots(prev => prev.map((s, idx) => idx === slotId ? { ...s, status: 'processing', serverJobId: data.job_id } : s));
      await pollJob(slotId, data.job_id);
    } catch (err) {
      setSlots(prev => prev.map((s, idx) => idx === slotId ? { ...s, status: 'error', error: err.message } : s));
    }
  };

  const handleMasterSelect = (e) => {
    Array.from(e.target.files).filter(f => f.type.startsWith('video/')).forEach((file, idx) => {
      if (idx < 3) uploadToSlot(file, idx);
    });
    e.target.value = '';
  };

  const handleSlotSelect = (e, slotId) => {
    const file = e.target.files[0];
    if (file && file.type.startsWith('video/')) uploadToSlot(file, slotId);
    e.target.value = '';
  };

  return (
    <div className="space-y-4 font-sans">
      {/* Header */}
      <div className="bg-[#13161a] border border-[#2a2e38] rounded-lg p-3 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2 font-sans text-xs text-[#5B8DBF] font-bold">
          <Film className="w-4 h-4 text-[#5B8DBF]" />
          <span>3-SCREEN MULTI-VIDEO THREAT DETECTOR (NSG CONFIG)</span>
        </div>
        <button
          onClick={() => fileInputRefMaster.current?.click()}
          className="w-full sm:w-auto px-4 py-2 bg-[#5B8DBF] hover:bg-[#48739f] text-white font-bold text-xs rounded-lg flex items-center justify-center gap-2 border border-[#5B8DBF]/50 transition-all active:scale-95 shrink-0"
        >
          <Upload className="w-4 h-4" />
          <span>UPLOAD 3 VIDEOS AT ONCE</span>
        </button>
        <input ref={fileInputRefMaster} type="file" multiple accept="video/*" onChange={handleMasterSelect} className="hidden" />
      </div>

      {/* 3-Screen Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {SLOT_CONFIGS.map((cfg, slotId) => {
          const slot = slots[slotId];
          const result = slot.result;
          const detections = result?.detections || [];
          const criticalThreats = detections.filter(d =>
            d.threat_level === 'CRITICAL_THREAT' || d.class_name === 'knife' || d.class_name === 'scissors'
          );

          return (
            <div key={slotId} className="bg-[#13161a] border border-[#2a2e38] rounded-lg overflow-hidden flex flex-col">
              {/* Screen header */}
              <div className="bg-[#181b22] px-4 py-2.5 border-b border-[#2a2e38] flex items-center justify-between font-sans text-xs">
                <div className="flex items-center gap-2">
                  <span className={`w-2.5 h-2.5 rounded-full ${
                    slot.status === 'done' ? 'bg-[#5B8DBF] animate-pulse'
                    : slot.status === 'processing' ? 'bg-[#5B8DBF] animate-spin'
                    : 'bg-slate-600'
                  }`} />
                  <span className="font-bold text-white tracking-wider">{cfg.label}</span>
                </div>
                <span className="text-[10px] text-[#5B8DBF] font-semibold">{cfg.zone}</span>
              </div>

              {/* Viewport */}
              <div className="relative aspect-video bg-black flex flex-col items-center justify-center border-b border-[#2a2e38] overflow-hidden">
                {slot.status === 'done' && result?.annotated_video_url ? (
                  <video src={result.annotated_video_url} controls autoPlay muted loop className="w-full h-full object-cover" />
                ) : slot.status === 'processing' ? (
                  <div className="flex flex-col items-center justify-center p-6 text-center space-y-2">
                    <Loader2 className="w-8 h-8 text-[#5B8DBF] animate-spin" />
                    <span className="text-xs font-sans font-bold text-[#5B8DBF]">YOLOv8 Processing...</span>
                    <span className="text-[10px] font-sans text-slate-500">Detecting Weapons &amp; Threats</span>
                  </div>
                ) : slot.status === 'uploading' ? (
                  <div className="flex flex-col items-center justify-center p-6 text-center space-y-2">
                    <Loader2 className="w-8 h-8 text-[#5B8DBF] animate-spin" />
                    <span className="text-xs font-sans font-bold text-[#5B8DBF]">Uploading...</span>
                  </div>
                ) : (
                  <div
                    onClick={() => slotInputRefs[slotId].current?.click()}
                    className="w-full h-full p-6 flex flex-col items-center justify-center text-center cursor-pointer hover:bg-[#181b22]/30 transition-colors group"
                  >
                    <Video className="w-8 h-8 text-slate-600 group-hover:text-[#5B8DBF] mb-2" />
                    <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">Screen {slotId + 1} — Click to Upload</span>
                    <span className="text-[10px] font-sans text-slate-500 mt-1">MP4 / AVI / WebM</span>
                  </div>
                )}

                <input ref={slotInputRefs[slotId]} type="file" accept="video/*" onChange={e => handleSlotSelect(e, slotId)} className="hidden" />

                {slot.status === 'done' && criticalThreats.length > 0 && (
                  <div className="absolute top-2 left-2 bg-[#B54A3F]/90 px-2.5 py-1 rounded border border-[#B54A3F] text-[11px] font-sans text-red-100 font-bold flex items-center gap-1.5">
                    <ShieldAlert className="w-3.5 h-3.5 text-white" />
                    <span>THREAT DETECTED</span>
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="p-3 bg-[#0a0e17] space-y-2 font-mono text-xs flex-1 flex flex-col justify-between">
                {slot.status === 'done' && result ? (
                  <div className="space-y-2">
                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <div className="bg-[#05080c] p-2 rounded border border-[#aa7c11]/25">
                        <span className="text-slate-400 block text-[10px]">DETECTIONS</span>
                        <span className="text-[#d4af37] font-bold">{result.detection_count} Objects</span>
                      </div>
                      <div className="bg-[#05080c] p-2 rounded border border-[#aa7c11]/25">
                        <span className="text-slate-400 block text-[10px]">PROC TIME</span>
                        <span className="text-[#d4af37] font-bold">{result.processing_time_sec}s</span>
                      </div>
                    </div>
                    {criticalThreats.length > 0 ? (
                      <div className="bg-[#450a0a]/30 border border-red-900 rounded p-2 text-red-300 text-[10px] space-y-1">
                        <div className="font-bold flex items-center gap-1">
                          <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
                          <span>CRITICAL ALERTS:</span>
                        </div>
                        {criticalThreats.slice(0, 2).map((t, i) => (
                          <div key={i}>• {t.threat_description || `${t.class_name.toUpperCase()} (${(t.confidence * 100).toFixed(0)}%)`}</div>
                        ))}
                      </div>
                    ) : (
                      <div className="bg-emerald-950/40 border border-emerald-900 rounded p-2 text-emerald-300 text-[10px] flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span>FEED SECURE — NO THREATS</span>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-[11px] text-slate-500 italic text-center py-2">
                    Awaiting Screen {slotId + 1} upload...
                  </div>
                )}
                <button
                  onClick={() => slotInputRefs[slotId].current?.click()}
                  className="w-full py-1.5 bg-[#111a2e] hover:bg-[#aa7c11]/20 text-[#d4af37] rounded text-[11px] font-mono border border-[#aa7c11]/30"
                >
                  {slot.status === 'done' ? `Replace Screen ${slotId + 1}` : 'Select Video'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Audit Trail */}
      {slots.some(s => s.status === 'done') && (
        <div className="bg-[#05080c] border border-[#aa7c11]/30 rounded-xl p-4 space-y-3 shadow-xl">
          <h3 className="text-xs font-mono font-bold text-[#d4af37] uppercase tracking-widest flex items-center gap-2">
            <Radio className="w-4 h-4 animate-pulse" />
            DETECTION AUDIT TRAIL — {slots.filter(s => s.status === 'done').length} Active Screens
          </h3>
          {slots.filter(s => s.status === 'done' && s.result).map((slot, idx) => (
            <div key={idx} className="bg-[#0a0e17] rounded-lg p-3 border border-[#aa7c11]/20">
              <div className="flex items-center justify-between text-xs font-mono mb-2">
                <span className="font-bold text-white">{SLOT_CONFIGS[slot.slotId].label}</span>
                <span className="text-[#d4af37] text-[10px]">SHA-256: {slot.result.file_hash?.substring(0, 20)}...</span>
              </div>
              {slot.result.detections?.length > 0 && (
                <div className="overflow-x-auto">
                  <table className="w-full text-[10px] font-mono">
                    <thead>
                      <tr className="text-slate-400 bg-[#05080c]">
                        <th className="px-2 py-1 text-left">Track</th>
                        <th className="px-2 py-1 text-left">Class</th>
                        <th className="px-2 py-1 text-left">Level</th>
                        <th className="px-2 py-1 text-left">Conf</th>
                        <th className="px-2 py-1 text-left">Time</th>
                      </tr>
                    </thead>
                    <tbody>
                      {slot.result.detections.slice(0, 5).map((det, i) => (
                        <tr key={i} className="border-t border-[#aa7c11]/10">
                          <td className="px-2 py-1 text-[#d4af37]">#{det.track_id}</td>
                          <td className="px-2 py-1 text-white capitalize">{det.class_name}</td>
                          <td className="px-2 py-1">
                            {det.threat_level === 'CRITICAL_THREAT'
                              ? <span className="text-red-300 font-bold bg-red-900/40 px-1 rounded text-[9px]">CRITICAL</span>
                              : <span className="text-slate-500 text-[9px]">NORMAL</span>}
                          </td>
                          <td className="px-2 py-1 text-emerald-400 font-bold">{(det.confidence * 100).toFixed(0)}%</td>
                          <td className="px-2 py-1 text-slate-400">{det.timestamp_sec?.toFixed(2)}s</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
