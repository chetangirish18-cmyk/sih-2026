/**
 * SENTINEL-X Data & API Bridge Service
 * Handles live backend REST requests with complete standalone offline fallback.
 */

const API_BASE_URL = 'http://localhost:8000/api';

export const mockCameras = [
  {
    id: "CAM-DRONE-01",
    name: "Aerial Recon Drone (Falcon-1)",
    type: "Surveillance Drone",
    zone_id: "ZONE-A",
    zone_name: "Outer Perimeter Gate",
    stream_url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    status: "ONLINE",
    battery: "84%",
    altitude: "45m",
    lat: 28.5355,
    lng: 77.3910,
    night_vision: true
  },
  {
    id: "CAM-ROBOT-02",
    name: "Tactical Scout Robot (Scout-X)",
    type: "Tactical Robot",
    zone_id: "ZONE-B",
    zone_name: "North Courtyard",
    stream_url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
    status: "ONLINE",
    battery: "92%",
    speed: "1.2 m/s",
    lat: 28.5358,
    lng: 77.3915,
    thermal_mode: true
  },
  {
    id: "CAM-BODYCAM-04",
    name: "Assault Operator BodyCam (Alpha-Lead)",
    type: "Body Camera",
    zone_id: "ZONE-C",
    zone_name: "Building Entrance",
    stream_url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
    status: "ONLINE",
    operator_name: "Operator Alpha",
    heart_rate: "112 bpm",
    lat: 28.5361,
    lng: 77.3918,
    audio_enabled: true
  },
  {
    id: "CAM-CCTV-01",
    name: "Perimeter CCTV (Cam-01)",
    type: "Stationary CCTV",
    zone_id: "ZONE-A",
    zone_name: "Outer Perimeter Gate",
    stream_url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyflights.mp4",
    status: "ONLINE",
    resolution: "4K UHD",
    fps: 30,
    lat: 28.5354,
    lng: 77.3908,
    ptz_enabled: true
  },
  {
    id: "CAM-CCTV-02",
    name: "Main Entrance CCTV (Cam-02)",
    type: "Stationary CCTV",
    zone_id: "ZONE-D",
    zone_name: "Restricted Command Core",
    stream_url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
    status: "ONLINE",
    resolution: "1080p HD",
    fps: 60,
    lat: 28.5364,
    lng: 77.3922,
    infrared: true
  }
];

export const mockIncident = {
  incident_id: "INC-2026-0828-01",
  title: "Perimeter Breach & Restricted Area Infiltration",
  status: "ACTIVE_INVESTIGATION",
  overall_risk_score: 89,
  risk_classification: "CRITICAL THREAT",
  created_at: "2026-08-28T02:14:10Z",
  updated_at: "2026-08-28T02:15:05Z",
  primary_location: "Complex Sector 4 (Zone A -> Zone D)",
  events: [
    {
      event_id: "EVT-101",
      camera_id: "CAM-DRONE-01",
      camera_name: "Aerial Recon Drone (Falcon-1)",
      camera_type: "Surveillance Drone",
      zone_id: "ZONE-A",
      zone_name: "Outer Perimeter Gate",
      timestamp: "2026-08-28T02:14:10Z",
      time_offset_sec: 0,
      object_type: "Vehicle / Person",
      detection_label: "Unregistered SUV Arrival & Person Alighting",
      confidence: 0.94,
      risk_score: 62,
      bounding_box: { x: 15, y: 20, width: 35, height: 40 },
      target_id: "TARGET-X9",
      explanation: {
        what: "Dark SUV stopped near outer perimeter fence line. Male subject in dark tactical jacket exited vehicle.",
        where: "Zone A (Outer Perimeter Gate), GPS: 28.5355, 77.3910",
        when: "02:14:10 UTC",
        why_abnormal: "Vehicle failed to broadcast scheduled RFID tag at vehicle checkpost.",
        evidence_clip_seconds: "02:14:00 - 02:14:20"
      }
    },
    {
      event_id: "EVT-102",
      camera_id: "CAM-ROBOT-02",
      camera_name: "Tactical Scout Robot (Scout-X)",
      camera_type: "Tactical Robot",
      zone_id: "ZONE-B",
      zone_name: "North Courtyard",
      timestamp: "2026-08-28T02:14:28Z",
      time_offset_sec: 18,
      object_type: "Person / Unattended Object",
      detection_label: "Loitering & Unattended Object Left behind",
      confidence: 0.91,
      risk_score: 85,
      bounding_box: { x: 45, y: 30, width: 25, height: 35 },
      target_id: "TARGET-X9",
      explanation: {
        what: "Subject matching TARGET-X9 description observed loitering for 14 seconds, dropping dark tactical backpack beside HVAC pillar.",
        where: "Zone B (North Courtyard), GPS: 28.5358, 77.3915",
        when: "02:14:28 UTC (18 seconds post Perimeter entry)",
        why_abnormal: "Thermal signatures confirm dropped item retains elevated mass density; subject departed bag vicinity rapidly.",
        evidence_clip_seconds: "02:14:20 - 02:14:40"
      }
    },
    {
      event_id: "EVT-103",
      camera_id: "CAM-BODYCAM-04",
      camera_name: "Assault Operator BodyCam (Alpha-Lead)",
      camera_type: "Body Camera",
      zone_id: "ZONE-C",
      zone_name: "Building Entrance",
      timestamp: "2026-08-28T02:14:36Z",
      time_offset_sec: 26,
      object_type: "Person",
      detection_label: "Rapid Concealed Movement & Door Bypass",
      confidence: 0.88,
      risk_score: 78,
      bounding_box: { x: 30, y: 15, width: 30, height: 50 },
      target_id: "TARGET-X9",
      explanation: {
        what: "Operator BodyCam captured TARGET-X9 sprinting through east courtyard corridor towards building lobby entrance.",
        where: "Zone C (Building Entrance), GPS: 28.5361, 77.3918",
        when: "02:14:36 UTC (8 seconds post Bag Drop)",
        why_abnormal: "Velocity exceeding normal pedestrian speed; trajectory correlates directly with connected Zone B path.",
        evidence_clip_seconds: "02:14:30 - 02:14:45"
      }
    },
    {
      event_id: "EVT-104",
      camera_id: "CAM-CCTV-02",
      camera_name: "Main Entrance CCTV (Cam-02)",
      camera_type: "Stationary CCTV",
      zone_id: "ZONE-D",
      zone_name: "Restricted Command Core",
      timestamp: "2026-08-28T02:14:50Z",
      time_offset_sec: 40,
      object_type: "Person / Restricted Breach",
      detection_label: "Forced Entry Breach - Restricted Access Door",
      confidence: 0.96,
      risk_score: 96,
      bounding_box: { x: 55, y: 25, width: 25, height: 45 },
      target_id: "TARGET-X9",
      explanation: {
        what: "Target forced open magnetic lock on Server Vault Door D-02 and entered restricted Command Core.",
        where: "Zone D (Restricted Command Core), GPS: 28.5364, 77.3922",
        when: "02:14:50 UTC (40 seconds post initial Drone detection)",
        why_abnormal: "Access card override triggered without authorized biometric verification.",
        evidence_clip_seconds: "02:14:45 - 02:15:05"
      }
    }
  ]
};

export async function fetchCameras() {
  try {
    const res = await fetch(`${API_BASE_URL}/cameras`);
    if (res.ok) return await res.json();
  } catch (e) {
    console.warn("Backend API offline, using local mock cameras service.", e);
  }
  return mockCameras;
}

export async function fetchIncidentDetails() {
  try {
    const res = await fetch(`${API_BASE_URL}/incidents`);
    if (res.ok) {
      const data = await res.json();
      return data.incidents ? data.incidents[0] : (data[0] || mockIncident);
    }
  } catch (e) {
    console.warn("Backend API offline, using local mock incident service.", e);
  }
  return mockIncident;
}

export async function generateAIReport(incidentId) {
  try {
    const res = await fetch(`${API_BASE_URL}/report/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ incident_id: incidentId })
    });
    if (res.ok) {
      const data = await res.json();
      return {
        incident_id: data.report_id,
        title: mockIncident.title,
        generated_at: data.generated_at,
        classification: data.classification,
        overall_risk_score: mockIncident.overall_risk_score,
        risk_level: "CRITICAL THREAT",
        executive_summary: data.audit_note || "EXECUTIVE TACTICAL BRIEF: SENTINEL-X correlated event detections across heterogeneous cameras.",
        spatial_movement_path: "Outer Perimeter Gate -> North Courtyard -> Building Entrance -> Restricted Command Core",
        chronological_narrative: data.sections.flatMap(sec => 
          sec.events.map((e, idx) => ({
            step: idx + 1,
            timestamp: e.citation.timestamp,
            source: e.citation.source_id,
            zone: e.citation.zone,
            observation: e.sentence,
            tactical_significance: "Correlated observation point",
            evidence_ref: `Frame ${e.citation.frame_number}`
          }))
        ),
        action_recommendations: [
          "Dispatch Quick Reaction Team (QRT-1) to secure Restricted Command Core (Zone D).",
          "Deploy Bomb Disposal Squad (BDS) to inspect unattended dropped package at HVAC pillar (Zone B).",
          "Issue immediate intercept directive for vehicle registered near Outer Gate (Zone A).",
          "Lock down Server Vault Door D-02 and preserve digital audit trail clips."
        ],
        evidence_clips_count: data.citations ? data.citations.length : 0,
        export_formats_available: ["PDF", "MARKDOWN", "JSON", "TACTICAL_XML"]
      };
    }
  } catch (e) {
    console.warn("Backend API offline, synthesizing local AI Report.", e);
  }
  
  // Local synthesis fallback
  return {
    incident_id: incidentId,
    title: mockIncident.title,
    generated_at: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC',
    classification: "TOP SECRET / NSG TACTICAL INTELLIGENCE",
    overall_risk_score: mockIncident.overall_risk_score,
    risk_level: "CRITICAL THREAT",
    executive_summary: "EXECUTIVE TACTICAL BRIEF: SENTINEL-X correlated 4 sequential event detections across 4 heterogeneous cameras (Drone, Robot, BodyCam, CCTV). TARGET-X9 arrived in an unregistered SUV at Zone A, dropped an unattended package in Zone B courtyard, executed a rapid sprint through Zone C, and breached restricted Command Core door D-02 in Zone D within 40 seconds.",
    spatial_movement_path: "Outer Perimeter Gate -> North Courtyard -> Building Entrance -> Restricted Command Core",
    chronological_narrative: mockIncident.events.map((e, idx) => ({
      step: idx + 1,
      timestamp: e.timestamp,
      source: `${e.camera_name} [${e.camera_type}]`,
      zone: e.zone_name,
      observation: e.explanation.what,
      tactical_significance: e.explanation.why_abnormal,
      evidence_ref: e.explanation.evidence_clip_seconds
    })),
    action_recommendations: [
      "Dispatch Quick Reaction Team (QRT-1) to secure Restricted Command Core (Zone D).",
      "Deploy Bomb Disposal Squad (BDS) to inspect unattended dropped package at HVAC pillar (Zone B).",
      "Issue immediate intercept directive for vehicle registered near Outer Gate (Zone A).",
      "Lock down Server Vault Door D-02 and preserve digital audit trail clips (EVT-101 through EVT-104)."
    ],
    evidence_clips_count: mockIncident.events.length,
    export_formats_available: ["PDF", "MARKDOWN", "JSON", "TACTICAL_XML"]
  };
}
