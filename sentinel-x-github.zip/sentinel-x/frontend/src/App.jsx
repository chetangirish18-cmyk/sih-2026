import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import MultiCameraGrid from './components/MultiCameraGrid';
import IncidentTimeline from './components/IncidentTimeline';
import ZoneMapView from './components/ZoneMapView';
import ExplainableAICard from './components/ExplainableAICard';
import IncidentReportModal from './components/IncidentReportModal';
import OperatorFeedback from './components/OperatorFeedback';
import MobileConnectModal from './components/MobileConnectModal';
import MobileCameraBroadcaster from './components/MobileCameraBroadcaster';
import DroidCamModal from './components/DroidCamModal';
import DroidCamStreamer from './components/DroidCamStreamer';
import VideoUploadPanel from './components/VideoUploadPanel';
import { fetchCameras, fetchIncidentDetails } from './services/mockService';
import { Radio, AlertOctagon, CheckCircle2, ShieldCheck, Activity, LayoutGrid, Network, Map, Upload, FileText, Smartphone, Camera, Lock } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('upload');
  const [cameras, setCameras] = useState([]);
  const [incident, setIncident] = useState(null);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [showReportModal, setShowReportModal] = useState(false);
  const [showMobileConnectModal, setShowMobileConnectModal] = useState(false);
  const [showDroidCamModal, setShowDroidCamModal] = useState(false);
  const [isMobileBroadcastingMode, setIsMobileBroadcastingMode] = useState(false);
  const [droidCamConfig, setDroidCamConfig] = useState({ active: false, deviceId: '', ipUrl: '' });

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('mode') === 'mobile_cam') {
      setIsMobileBroadcastingMode(true);
    }

    async function initData() {
      const cams = await fetchCameras();
      const inc = await fetchIncidentDetails();
      setCameras(cams);
      setIncident(inc);
    }
    initData();
  }, []);

  const handleMobileFrameStream = (frameDataUrl) => {
    setCameras(prev => prev.map(cam => {
      if (cam.id === 'CAM-BODYCAM-04') {
        return {
          ...cam,
          name: "Body Camera (Officer-1 Mobile)",
          type: "Mobile Wireless BodyCam",
          stream_url: frameDataUrl
        };
      }
      return cam;
    }));
  };

  if (isMobileBroadcastingMode) {
    return (
      <MobileCameraBroadcaster
        onBackToDashboard={() => setIsMobileBroadcastingMode(false)}
        onFrameStream={handleMobileFrameStream}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#181b22] text-slate-100 flex flex-col font-sans">
      {/* Header Navbar */}
      <Navbar
        onOpenReport={() => setShowReportModal(true)}
        onOpenMobileConnect={() => setShowMobileConnectModal(true)}
        onOpenDroidCam={() => setShowDroidCamModal(true)}
        activeThreatCount={incident?.events?.length || 4}
      />

      {/* Main Dashboard Layout with Left Sidebar */}
      <div className="flex flex-1 flex-col lg:flex-row max-w-[1600px] w-full mx-auto">
        {/* Authoritative Command-Center Sidebar */}
        <aside className="w-full lg:w-72 bg-[#13161a] border-b lg:border-b-0 lg:border-r border-[#2a2e38] p-5 flex flex-col space-y-6 shrink-0 font-sans">
          <div>
            <span className="text-[10px] tracking-widest text-[#5B8DBF] font-bold uppercase block mb-3 opacity-90">
              OPERATIONAL VIEWS
            </span>
            <nav className="space-y-1.5">
              <button
                onClick={() => setActiveTab('upload')}
                className={`w-full flex items-center space-x-3 px-4 py-2.5 rounded-lg text-xs tracking-wide transition-all border ${
                  activeTab === 'upload'
                    ? 'bg-[#181b22] text-[#5B8DBF] border-[#5B8DBF] font-bold'
                    : 'text-slate-400 hover:text-white bg-[#13161a] border-[#2a2e38] hover:bg-[#181b22] font-semibold'
                }`}
              >
                <Upload className="w-4 h-4" />
                <span>MULTI-FEED ANALYZER</span>
              </button>
            </nav>
          </div>

          <div className="border-t border-[#2a2e38] pt-5">
            <span className="text-[10px] tracking-widest text-[#5B8DBF] font-bold uppercase block mb-3 opacity-90">
              TACTICAL INTEGRATIONS
            </span>
            <div className="space-y-2">
              <button
                onClick={() => setShowDroidCamModal(true)}
                className="w-full flex items-center space-x-3 px-4 py-2 bg-[#181b22] hover:bg-[#1f232b] text-slate-300 hover:text-white rounded-lg text-xs border border-[#2a2e38] transition-all"
              >
                <Camera className="w-4 h-4 text-[#5B8DBF]" />
                <span>CONNECT DROIDCAM (C-05)</span>
              </button>
            </div>
          </div>
        </aside>

        {/* Content Container */}
        <main className="flex-1 p-5 lg:p-6 overflow-y-auto space-y-6">
          {activeTab === 'grid' && (
            <MultiCameraGrid
              cameras={cameras}
              incident={incident}
              onSelectEvent={(evt) => setSelectedEvent(evt)}
            />
          )}

          {activeTab === 'timeline' && (
            <IncidentTimeline
              incident={incident}
              onSelectEvent={(evt) => setSelectedEvent(evt)}
              onOpenReport={() => setShowReportModal(true)}
            />
          )}

          {activeTab === 'zonemap' && (
            <ZoneMapView
              cameras={cameras}
              incident={incident}
              onSelectEvent={(evt) => setSelectedEvent(evt)}
            />
          )}

          {activeTab === 'upload' && (
            <div className="space-y-6 font-sans">
              <div className="bg-[#13161a] border border-[#2a2e38] rounded-lg p-5">
                <VideoUploadPanel />
              </div>
              
              {droidCamConfig.active && (
                <DroidCamStreamer 
                  onEvidenceSaved={(evidence) => console.log("Evidence saved:", evidence)}
                />
              )}
            </div>
          )}

          {/* Human Operator Feedback Section */}
          <div className="pt-2">
            <OperatorFeedback incident={incident} />
          </div>
        </main>
      </div>

      {/* Footer */}
      <footer className="bg-[#13161a] border-t border-[#2a2e38] p-4 text-center text-xs text-slate-500 font-sans">
        SENTINEL-X • AI and ML Enabled Video Analysis and Interpretation Platform • SIH 2025 | MHA / NSG
      </footer>

      {/* Explainable AI Modal */}
      {selectedEvent && (
        <ExplainableAICard
          event={selectedEvent}
          onClose={() => setSelectedEvent(null)}
        />
      )}

      {/* AI Incident Report Modal */}
      {showReportModal && (
        <IncidentReportModal
          incidentId={incident?.incident_id}
          onClose={() => setShowReportModal(false)}
        />
      )}

      {/* DroidCam Configuration Modal */}
      {showDroidCamModal && (
        <DroidCamModal
          onClose={() => setShowDroidCamModal(false)}
          onConnect={(cfg) => setDroidCamConfig({ active: true, ...cfg })}
        />
      )}

      {/* Wireless Smartphone Pair Modal */}
      {showMobileConnectModal && (
        <MobileConnectModal
          hostIp="172.20.129.131"
          onClose={() => setShowMobileConnectModal(false)}
          onLaunchMobileCam={() => {
            setShowMobileConnectModal(false);
            setIsMobileBroadcastingMode(true);
          }}
        />
      )}

    </div>
  );
}
