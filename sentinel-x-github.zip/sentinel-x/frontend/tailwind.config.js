/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        tactical: {
          dark: '#0a0d14',
          panel: '#121824',
          border: '#1e293b',
          accent: '#06b6d4',
          alert: '#ef4444',
          warning: '#f59e0b',
          success: '#10b981',
          nsg: '#3b82f6'
        }
      }
    },
  },
  plugins: [],
}
