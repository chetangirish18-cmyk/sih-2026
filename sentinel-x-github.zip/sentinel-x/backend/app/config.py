"""
SENTINEL-X Configuration & Parameters
Cross-Source Incident Intelligence Platform (SIH 2025 - MHA / NSG)
"""
import os
from pydantic import BaseModel

class SystemConfig(BaseModel):
    APP_NAME: str = "SENTINEL-X"
    VERSION: str = "1.0.0"
    TRACK: str = "SIH 2025 | Ministry of Home Affairs (MHA) / National Security Guard (NSG)"
    
    # Connect Module Parameters
    TIME_PROXIMITY_THRESHOLD_SEC: float = 45.0  # Max delta-t between connected events across zones
    DEFAULT_RISK_SCORE_THRESHOLD: float = 65.0  # High risk alert threshold %
    
    # YOLO Model parameters
    YOLO_MODEL_NAME: str = "yolov8n.pt"
    CONFIDENCE_THRESHOLD: float = 0.45
    
    # Video Ingestion Sources
    CAMERA_TYPES: list[str] = ["Surveillance Drone", "Tactical Robot", "Body Camera", "Stationary CCTV"]
    
    # Data Storage Paths
    BASE_DIR: str = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    MOCK_DATA_DIR: str = os.path.join(BASE_DIR, "app", "mock_data")
    VIDEO_CACHE_DIR: str = os.path.join(BASE_DIR, "video_cache")

config = SystemConfig()
