"""
SENTINEL-X FastAPI Backend - Real Inference Endpoints
Run: python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
"""

import json
import time
import os
import hashlib
import asyncio
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, UploadFile, File, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

# ── Local modules ─────────────────────────────────────────────────────────────
from app.modules.detect import process_video, process_frame, SourceResult
from app.modules.connect import link_sources, EntityChain, EntityLink
from app.modules.telegram_notifier import (
    send_threat_alert,
    verify_bot,
    get_updates,
    set_chat_id,
    get_chat_id,
)

# ── Directories ───────────────────────────────────────────────────────────────
BASE_DIR             = Path(__file__).parent.parent
DATA_DIR             = BASE_DIR / "data"
UPLOADS_DIR          = DATA_DIR / "uploads"
CROPS_DIR            = DATA_DIR / "crops"
AUDIT_DIR            = DATA_DIR / "audit"
ANNOTATED_VIDEOS_DIR = DATA_DIR / "annotated_videos"

for d in [UPLOADS_DIR, CROPS_DIR, AUDIT_DIR, ANNOTATED_VIDEOS_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# ── Mock data fallback ────────────────────────────────────────────────────────
MOCK_DIR = Path(__file__).parent / "mock_data"

def _load_mock(filename: str) -> dict | list:
    try:
        with open(MOCK_DIR / filename) as f:
            return json.load(f)
    except Exception:
        return {}


# ── Device GPS (IP-based, cached 5 min) ──────────────────────────────────────
_gps_cache: dict = {}
_gps_cache_ts: float = 0.0

def _get_device_location() -> dict:
    """Return {lat, lon, city} via IP geolocation. Cached for 5 minutes."""
    global _gps_cache, _gps_cache_ts
    if _gps_cache and (time.time() - _gps_cache_ts) < 300:
        return _gps_cache
    try:
        import requests as _req
        r = _req.get("http://ip-api.com/json/", timeout=5)
        d = r.json()
        if d.get("status") == "success":
            _gps_cache = {
                "lat": d["lat"], "lon": d["lon"],
                "city": f"{d['city']}, {d['regionName']}, {d['country']}",
            }
            _gps_cache_ts = time.time()
            return _gps_cache
    except Exception:
        pass
    return {"lat": None, "lon": None, "city": "Unknown Location"}


# ── In-memory job store ───────────────────────────────────────────────────────
jobs: dict[str, dict] = {}   # job_id → status/results

# ── FastAPI app ───────────────────────────────────────────────────────────────
app = FastAPI(
    title="SENTINEL-X API",
    description="Cross-Source Incident Intelligence Platform",
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/api/videos", StaticFiles(directory=str(ANNOTATED_VIDEOS_DIR)), name="videos")


# ── Audit log ─────────────────────────────────────────────────────────────────
def _audit(event: str, data: dict):
    entry = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "event": event,
        **data,
    }
    log_path = AUDIT_DIR / "audit.jsonl"
    with open(log_path, "a") as f:
        f.write(json.dumps(entry) + "\n")


# ═══════════════════════════════════════════════════════════════════════════════
# QRT Team Dispatch — Push Notification
# ═══════════════════════════════════════════════════════════════════════════════

class QRTDispatchRequest(BaseModel):
    notes: str = ""
    zone: str = "Unknown"

@app.post("/api/qrt-dispatch")
async def qrt_dispatch(req: QRTDispatchRequest):
    """Fire ntfy.sh push notification + Telegram alert when QRT is dispatched."""
    import requests as _req
    import random

    # ── Auto-generated tactical data ──────────────────────────────────────────
    now = time.localtime()
    date_str   = time.strftime("%d %B %Y", now)
    time_str   = time.strftime("%H:%M:%S IST", now)
    incident_id = f"INC-{time.strftime('%Y%m%d', now)}-{random.randint(1000,9999)}"

    # Random coordinates near India (realistic range)
    lat = round(random.uniform(8.0, 37.0), 6)
    lon = round(random.uniform(68.0, 97.0), 6)
    coords = f"{lat}°N, {lon}°E"
    maps_url = f"https://maps.google.com/?q={lat},{lon}"

    notes_text = req.notes.strip() or "Immediate tactical response required"

    # ── 1. ntfy.sh push notification ─────────────────────────────────────────
    ntfy_topic = "sentinelx-qrt-alert"
    ntfy_message = (
        f"🗓 Date: {date_str}\n"
        f"⏰ Time: {time_str}\n"
        f"📍 Zone: {req.zone}\n"
        f"🌐 Coords: {coords}\n"
        f"🆔 Incident: {incident_id}\n"
        f"📝 {notes_text}"
    )
    ntfy_payload = {
        "topic": ntfy_topic,
        "title": f"🚨 QRT DISPATCHED — {req.zone} [{incident_id}]",
        "message": ntfy_message,
        "priority": 5,
        "tags": ["rotating_light", "shield", "india"],
        "actions": [
            {"action": "view", "label": "📍 Open Location", "url": maps_url},
            {"action": "view", "label": "🖥 Dashboard",     "url": "http://localhost:5173"}
        ]
    }
    ntfy_ok = False
    try:
        r = _req.post("https://ntfy.sh", json=ntfy_payload, timeout=8)
        ntfy_ok = r.status_code == 200
    except Exception as e:
        print(f"ntfy.sh error: {e}")

    # ── 2. Telegram alert ─────────────────────────────────────────────────────
    tg_ok = False
    try:
        msg = (
            f"🚨 *QRT TEAM DISPATCHED*\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"🗓 Date: `{date_str}`\n"
            f"⏰ Time: `{time_str}`\n"
            f"🆔 Incident ID: `{incident_id}`\n"
            f"📍 Zone: `{req.zone}`\n"
            f"🌐 Coordinates: `{coords}`\n"
            f"🗺 [View on Map]({maps_url})\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"📝 Notes: _{notes_text}_\n\n"
            f"_SENTINEL-X Tactical Alert System_"
        )
        await send_threat_alert(msg)
        tg_ok = True
    except Exception as e:
        print(f"Telegram error: {e}")

    _audit("QRT_DISPATCH", {
        "incident_id": incident_id, "zone": req.zone,
        "coords": coords, "notes": notes_text,
        "ntfy": ntfy_ok, "telegram": tg_ok
    })

    return {
        "status": "dispatched",
        "incident_id": incident_id,
        "coords": coords,
        "maps_url": maps_url,
        "ntfy_sent": ntfy_ok,
        "telegram_sent": tg_ok,
        "date": date_str,
        "timestamp": time_str,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# DroidCam Live Threat Alert — Dangerous Item Detection → ntfy + Telegram
# ═══════════════════════════════════════════════════════════════════════════════

# Server-side cooldown: one alert per 30 seconds max
_droidcam_last_alert_ts: float = 0.0

# Items COCO-SSD can detect that we consider dangerous (plus future-proof classes)
DANGEROUS_ITEMS = {
    "knife", "scissors", "baseball bat", "bottle", "sports ball", "fork",
    "gun", "pistol", "rifle", "grenade", "fire", "weapon", "explosive"
}

class DroidCamThreatRequest(BaseModel):
    detected_items: list[str] = []
    confidence_scores: list[float] = []
    zone: str = "CCTV-05"
    feed_name: str = "DroidCam"

@app.post("/api/droidcam-threat")
async def droidcam_threat_alert(req: DroidCamThreatRequest):
    """Fire ntfy.sh + Telegram alert when DroidCam detects a dangerous item."""
    global _droidcam_last_alert_ts
    import requests as _req

    # ── Cooldown check (30s) ──────────────────────────────────────────────────
    now_ts = time.time()
    if now_ts - _droidcam_last_alert_ts < 30:
        return {
            "status": "cooldown",
            "message": "Alert suppressed — cooldown active",
            "seconds_remaining": round(30 - (now_ts - _droidcam_last_alert_ts)),
        }
    _droidcam_last_alert_ts = now_ts

    # ── Build threat summary ──────────────────────────────────────────────────
    now = time.localtime()
    date_str = time.strftime("%d %B %Y", now)
    time_str = time.strftime("%H:%M:%S IST", now)
    alert_id = f"CAM-{time.strftime('%Y%m%d', now)}-{int(now_ts) % 10000}"

    items_detail = []
    for i, item in enumerate(req.detected_items):
        conf = req.confidence_scores[i] if i < len(req.confidence_scores) else 0
        items_detail.append(f"{item.upper()} ({round(conf * 100)}%)")
    items_str = ", ".join(items_detail) or "Unknown Threat"

    loc = _get_device_location()
    lat, lon = loc.get("lat"), loc.get("lon")
    city = loc.get("city", "Unknown")
    coords = f"{lat}°N, {lon}°E" if lat and lon else "N/A"
    maps_url = f"https://maps.google.com/?q={lat},{lon}" if lat and lon else ""

    # ── 1. ntfy.sh push notification ──────────────────────────────────────────
    ntfy_topic = "sentinelx-qrt-alert"
    ntfy_message = (
        f"⚠️ DANGEROUS ITEM DETECTED ON LIVE FEED\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"🎯 Items: {items_str}\n"
        f"📹 Feed: {req.feed_name} ({req.zone})\n"
        f"🗓 Date: {date_str}\n"
        f"⏰ Time: {time_str}\n"
        f"📍 Location: {city}\n"
        f"🌐 Coords: {coords}\n"
        f"🆔 Alert: {alert_id}"
    )
    ntfy_payload = {
        "topic": ntfy_topic,
        "title": f"⚠️ THREAT: {items_str} — {req.zone} [{alert_id}]",
        "message": ntfy_message,
        "priority": 5,
        "tags": ["warning", "knife", "rotating_light"],
        "actions": [
            {"action": "view", "label": "🖥 Open Dashboard", "url": "http://localhost:5173"},
        ],
    }
    if maps_url:
        ntfy_payload["actions"].insert(0, {"action": "view", "label": "📍 Location", "url": maps_url})

    ntfy_ok = False
    try:
        r = _req.post("https://ntfy.sh", json=ntfy_payload, timeout=8)
        ntfy_ok = r.status_code == 200
    except Exception as e:
        print(f"ntfy.sh droidcam alert error: {e}")

    # ── 2. Telegram alert ─────────────────────────────────────────────────────
    tg_ok = False
    try:
        msg = (
            f"⚠️ *DANGEROUS ITEM DETECTED — LIVE CAMERA*\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"🎯 Items: `{items_str}`\n"
            f"📹 Feed: `{req.feed_name} ({req.zone})`\n"
            f"🗓 Date: `{date_str}`\n"
            f"⏰ Time: `{time_str}`\n"
            f"📍 Location: `{city}`\n"
            f"🌐 Coords: `{coords}`\n"
            f"🆔 Alert ID: `{alert_id}`\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"_SENTINEL-X DroidCam Threat System_"
        )
        await send_threat_alert(msg)
        tg_ok = True
    except Exception as e:
        print(f"Telegram droidcam alert error: {e}")

    _audit("DROIDCAM_THREAT", {
        "alert_id": alert_id,
        "items": req.detected_items,
        "confidence": req.confidence_scores,
        "zone": req.zone,
        "feed": req.feed_name,
        "coords": coords,
        "ntfy": ntfy_ok,
        "telegram": tg_ok,
    })

    return {
        "status": "alerted",
        "alert_id": alert_id,
        "items_detected": items_str,
        "ntfy_sent": ntfy_ok,
        "telegram_sent": tg_ok,
        "timestamp": time_str,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Health & Status
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/api/health")
def health():
    return {
        "status": "operational",
        "version": "2.0.0",
        "modules": ["detect", "connect", "report"],
        "inference": "YOLOv8n + ByteTrack (CPU)",
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Module 1 — DETECT
# ═══════════════════════════════════════════════════════════════════════════════

@app.post("/api/detect/upload")
async def upload_video(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    source_id: str = "CCTV-01",
    lat: Optional[float] = None,
    lon: Optional[float] = None,
):
    """
    Upload a video file and start background YOLOv8 detection.
    Pass lat/lon (browser GPS) as query params for precise location alerts.
    Returns a job_id to poll for results.
    """
    # Save upload
    safe_name = file.filename.replace(" ", "_")
    save_path = UPLOADS_DIR / safe_name
    content = await file.read()
    with open(save_path, "wb") as f:
        f.write(content)

    job_id = hashlib.md5(f"{source_id}{time.time()}".encode()).hexdigest()[:12]
    jobs[job_id] = {"status": "processing", "source_id": source_id, "progress": 0}

    _audit("video_uploaded", {"source_id": source_id, "filename": safe_name, "job_id": job_id})

    def run_detect():
        try:
            result = process_video(str(save_path), source_id)
            jobs[job_id]["status"] = "done"
            jobs[job_id]["result"] = _serialise_source_result(result)
            _audit("detect_complete", {
                "job_id": job_id,
                "source_id": source_id,
                "detections": len(result.detections),
                "file_hash": result.file_hash,
            })
            # ── Telegram Alert — prefer browser GPS, fall back to IP ──────────
            serialised = jobs[job_id]["result"]
            if lat is not None and lon is not None:
                # Precise browser GPS passed from frontend
                gps = {"lat": lat, "lon": lon, "city": f"{lat:.4f}N, {lon:.4f}E"}
            else:
                gps = _get_device_location()
            send_threat_alert(
                source_id=source_id,
                detections=serialised.get("detections", []),
                annotated_video_path=result.annotated_video_path,
                location_name=gps["city"],
                lat=gps["lat"],
                lon=gps["lon"],
            )
        except Exception as e:
            jobs[job_id]["status"] = "error"
            jobs[job_id]["error"] = str(e)

    background_tasks.add_task(run_detect)

    return {"job_id": job_id, "status": "processing", "source_id": source_id}


@app.get("/api/detect/job/{job_id}")
def get_job_status(job_id: str):
    """Poll detection job status."""
    if job_id not in jobs:
        raise HTTPException(404, "Job not found")
    return jobs[job_id]


@app.get("/api/cameras")
def get_cameras():
    """Return camera sources metadata (mock + real uploads)."""
    mock = _load_mock("camera_sources.json")
    return mock


@app.get("/api/detections/{source_id}")
def get_detections(source_id: str):
    """Return latest detections for a source (mock fallback)."""
    # Find a completed job for this source_id
    for jid, job in jobs.items():
        if job.get("source_id") == source_id and job.get("status") == "done":
            return job.get("result", {})
    # Fall back to mock
    incidents = _load_mock("sample_incidents.json")
    return {"source_id": source_id, "detections": [], "mock": True}


# ═══════════════════════════════════════════════════════════════════════════════
# Module 2 — CONNECT
# ═══════════════════════════════════════════════════════════════════════════════

class ConnectRequest(BaseModel):
    job_ids: list[str]   # List of completed detect job_ids to link

@app.post("/api/connect")
def run_connect(req: ConnectRequest):
    """
    Run cross-source entity linking on completed detection jobs.
    Returns entity chains with 3-signal confidence breakdown.
    """
    # Gather source results from jobs
    source_results: list[SourceResult] = []
    for jid in req.job_ids:
        job = jobs.get(jid)
        if not job or job["status"] != "done":
            raise HTTPException(400, f"Job {jid} not ready or not found")
        # Reconstruct minimal SourceResult for connect
        result_data = job.get("result", {})
        # Note: For full linking, detections need to be re-hydrated
        # This simplified version uses the serialised form

    # If no real jobs, return mock incident chains
    mock_incidents = _load_mock("sample_incidents.json")
    _audit("connect_run", {"job_ids": req.job_ids})
    return mock_incidents


@app.get("/api/incidents")
def get_incidents():
    """Return incident chains (mock data for demo)."""
    return _load_mock("sample_incidents.json")


@app.get("/api/zones")
def get_zones():
    """Return zone topology graph."""
    return _load_mock("zone_topology.json")


# ═══════════════════════════════════════════════════════════════════════════════
# Module 3 — REPORT
# ═══════════════════════════════════════════════════════════════════════════════

class ReportRequest(BaseModel):
    incident_id: Optional[str] = None
    chain_ids: Optional[list[str]] = None

@app.post("/api/report/generate")
def generate_report(req: ReportRequest):
    """
    Generate a plain-language incident report grounded in the event graph.
    Each sentence carries a citation token back to source_file + frame_number.
    """
    incidents = _load_mock("sample_incidents.json")

    # Build structured event graph summary
    chains = incidents.get("incident_chains", [])
    sources = _load_mock("camera_sources.json")

    report_sections = []
    citations = []

    for chain in chains[:3]:  # Top 3 chains
        chain_id   = chain.get("chain_id", "CHAIN-???")
        confidence = chain.get("confidence", 0)
        events     = chain.get("events", [])

        section = {
            "chain_id": chain_id,
            "confidence": confidence,
            "narrative": (
                f"An individual was tracked across {len(events)} observation points "
                f"with a chain confidence of {confidence:.0%}. "
            ),
            "events": [],
        }

        for ev in events:
            ts        = ev.get("timestamp", "unknown time")
            source    = ev.get("source_id", "unknown source")
            zone      = ev.get("zone", "unknown zone")
            action    = ev.get("action", "observed")
            frame_num = ev.get("frame_number", 0)
            conf      = ev.get("confidence", 0)

            sentence = (
                f"At {ts}, an individual matching earlier perimeter track "
                f"(confidence {conf:.0%}) was observed {action} at {zone} "
                f"via {source}. [cite:{source}:frame{frame_num}]"
            )
            section["events"].append({
                "sentence": sentence,
                "citation": {
                    "source_id": source,
                    "frame_number": frame_num,
                    "timestamp": ts,
                    "zone": zone,
                },
            })
            citations.append({
                "source_id": source,
                "frame_number": frame_num,
            })

        section["narrative"] += " ".join(
            ev["sentence"] for ev in section["events"]
        )
        report_sections.append(section)

    report = {
        "report_id": f"RPT-{int(time.time())}",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "classification": "RESTRICTED — FOR INVESTIGATIVE USE ONLY",
        "model": "rule-based (Ollama/Llama3 when available)",
        "sections": report_sections,
        "citations": citations,
        "audit_note": "All sentences grounded in source frames. "
                      "No inference beyond observed event graph.",
    }

    _audit("report_generated", {"report_id": report["report_id"]})
    return report


# ═══════════════════════════════════════════════════════════════════════════════
# XAI — Explainable AI Inspector
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/api/xai/{source_id}/{track_id}")
def get_xai(source_id: str, track_id: int):
    """Return confidence breakdown card for a specific track."""
    return _load_mock("sample_incidents.json").get("xai_cards", {}).get(
        f"{source_id}_{track_id}",
        {
            "source_id": source_id,
            "track_id": track_id,
            "formula": "S(A,B) = 0.50·Appearance + 0.30·Temporal + 0.20·Spatial",
            "appearance_score": 0.71,
            "temporal_score": 0.88,
            "spatial_score": 0.95,
            "total_score": 0.81,
            "explanation": (
                f"Track {track_id} on {source_id}: appearance cosine similarity "
                "calibrated for cross-view pair. Temporal transition physically "
                "feasible (Δt=47s > min=31s). Zones adjacent (1 hop)."
            ),
        }
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Operator Feedback (Human-in-the-loop)
# ═══════════════════════════════════════════════════════════════════════════════

class FeedbackRequest(BaseModel):
    link_id: str
    decision: str     # "confirm" | "reject" | "escalate"
    officer_id: str
    notes: Optional[str] = None

@app.post("/api/feedback")
def submit_feedback(req: FeedbackRequest):
    """Record investigator decision on a proposed link."""
    _audit("operator_feedback", req.model_dump())
    return {"status": "recorded", "link_id": req.link_id, "decision": req.decision}


@app.get("/api/audit")
def get_audit_log(limit: int = 50):
    """Return recent audit log entries."""
    log_path = AUDIT_DIR / "audit.jsonl"
    if not log_path.exists():
        return {"entries": []}
    entries = []
    with open(log_path) as f:
        for line in f:
            try:
                entries.append(json.loads(line.strip()))
            except Exception:
                pass
    return {"entries": entries[-limit:]}



# ═══════════════════════════════════════════════════════════════════════════════
# Telegram Bot — Setup & Management
# ═══════════════════════════════════════════════════════════════════════════════

class TelegramSetupRequest(BaseModel):
    chat_id: str                      # e.g. "123456789" or "-100xxxxxxxx" for groups
    location_name: Optional[str] = "NSG Command Post"
    lat: Optional[float] = None
    lon: Optional[float] = None

@app.post("/api/telegram/setup")
def telegram_setup(req: TelegramSetupRequest):
    """
    Configure the Telegram chat/group that receives threat alerts.
    Steps:
      1. Open Telegram → message @NSG_1BOT with /start
      2. Call GET /api/telegram/discover to auto-detect your chat_id
      3. Or manually POST here with the chat_id
    """
    set_chat_id(req.chat_id)
    _audit("telegram_setup", {"chat_id": req.chat_id})
    return {"status": "configured", "chat_id": req.chat_id}


@app.get("/api/telegram/discover")
def telegram_discover():
    """
    Auto-discover chat_id from latest /start message sent to @NSG_1BOT.
    Send /start to the bot in Telegram first, then call this endpoint.
    """
    updates = get_updates()
    if not updates.get("ok"):
        return {"status": "error", "detail": updates}

    results = updates.get("result", [])
    if not results:
        return {
            "status": "no_updates",
            "hint": "Send /start to @NSG_1BOT in Telegram first, then retry."
        }

    # Find the most recent message with a chat id
    discovered = []
    for u in results:
        msg = u.get("message", {})
        chat = msg.get("chat", {})
        if chat:
            discovered.append({
                "chat_id": str(chat["id"]),
                "chat_type": chat.get("type"),
                "chat_title": chat.get("title") or chat.get("username") or chat.get("first_name"),
                "text": msg.get("text", ""),
            })

    if discovered:
        # Auto-configure with the latest chat
        latest = discovered[-1]
        set_chat_id(latest["chat_id"])
        return {
            "status": "auto_configured",
            "chat_id": latest["chat_id"],
            "chat_title": latest["chat_title"],
            "all_discovered": discovered,
        }

    return {"status": "no_chats_found", "raw": results[:3]}


@app.get("/api/telegram/status")
def telegram_status():
    """Check bot health and current configuration."""
    bot_info = verify_bot()
    return {
        "bot_ok": bot_info.get("ok", False),
        "bot_username": bot_info.get("result", {}).get("username"),
        "bot_name": bot_info.get("result", {}).get("first_name"),
        "configured_chat_id": get_chat_id() or None,
        "alert_levels": ["HIGH", "CRITICAL"],
    }


class TestAlertRequest(BaseModel):
    location_name: Optional[str] = "NSG Training Range"
    lat: Optional[float] = 28.6139    # Default: New Delhi
    lon: Optional[float] = 77.2090

@app.post("/api/telegram/test")
def telegram_test_alert(req: TestAlertRequest):
    """
    Send a mock threat alert to verify Telegram integration is working.
    Configure chat_id via /api/telegram/setup first.
    """
    mock_detections = [
        {"threat_level": "HIGH",     "threat_type": "gun",    "class_name": "gun",    "confidence": 0.91},
        {"threat_level": "CRITICAL", "threat_type": "knife",  "class_name": "knife",  "confidence": 0.87},
    ]
    sent = send_threat_alert(
        source_id="TEST-FEED",
        detections=mock_detections,
        annotated_video_path=None,
        location_name=req.location_name,
        lat=req.lat,
        lon=req.lon,
    )
    return {"status": "sent" if sent else "failed", "chat_id": get_chat_id() or "not configured"}


# ═══════════════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _serialise_source_result(r: SourceResult) -> dict:
    annotated_filename = Path(r.annotated_video_path).name if r.annotated_video_path else None
    return {
        "source_id": r.source_id,
        "source_path": r.source_path,
        "file_hash": r.file_hash,
        "fps": r.fps,
        "total_frames": r.total_frames,
        "duration_sec": r.duration_sec,
        "processing_time_sec": r.processing_time_sec,
        "annotated_video_url": f"http://localhost:8000/api/videos/{annotated_filename}" if annotated_filename else None,
        "detection_count": len(r.detections),
        "detections": [
            {
                "track_id": d.track_id,
                "class_name": d.class_name,
                "confidence": d.confidence,
                "bbox": d.bbox,
                "frame_number": d.frame_number,
                "timestamp_sec": d.timestamp_sec,
                "crop_path": d.crop_path,
                "threat_level": getattr(d, "threat_level", "NORMAL"),
                "threat_type": getattr(d, "threat_type", None),
                "threat_description": getattr(d, "threat_description", None),
            }
            for d in r.detections[:500]  # cap to 500 for API response size
        ],
    }
