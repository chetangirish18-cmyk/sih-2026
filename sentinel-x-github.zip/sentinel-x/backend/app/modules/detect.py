"""
SENTINEL-X Module 1 — DETECT
Real YOLOv8 + ByteTrack per-source object detection & crop extraction.
"""

import cv2
import numpy as np
import hashlib
import os
import time
import imageio
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional
from ultralytics import YOLO

# ── Model singleton (loaded once, reused) ────────────────────────────────────
_model: Optional[YOLO] = None

MODEL_PATH_BASE = Path(__file__).parent.parent.parent / "yolov8n.pt"
MODEL_PATH_CUSTOM = Path(__file__).parent.parent.parent / "people_analysis_yolov8n.pt"
MODEL_PATH = MODEL_PATH_CUSTOM if MODEL_PATH_CUSTOM.exists() else MODEL_PATH_BASE
CROPS_DIR  = Path(__file__).parent.parent.parent / "data" / "crops"

COCO_CLASSES = {
    # ── People ────────────────────────────────────────────────────────────────
    0: "person",
    # ── Vehicles ─────────────────────────────────────────────────────────────
    1: "bicycle", 2: "car", 3: "motorcycle", 5: "bus", 7: "truck",
    # ── Animals ──────────────────────────────────────────────────────────────
    14: "bird", 15: "cat", 16: "dog",
    # ── Suspicious carry-on items ─────────────────────────────────────────────
    24: "backpack", 26: "handbag", 28: "suitcase",
    # ── ⚠ DANGEROUS WEAPONS (COCO 80-class) ─────────────────────────────────
    43: "knife",          # Bladed weapon
    76: "scissors",       # Sharp object / improvised weapon
    # ── Electronics / Concealment ─────────────────────────────────────────────
    63: "laptop", 67: "cell phone",
    # ── Sports objects usable as blunt weapons ────────────────────────────────
    34: "frisbee", 35: "skis", 38: "baseball bat",   # blunt impact threats
    39: "baseball glove", 40: "skateboard",
    73: "book", 74: "clock", 75: "vase",
    # ── Fire / Smoke indicators ───────────────────────────────────────────────
    # NOTE: YOLOv8 COCO has no native fire/smoke class.
    # Covered via custom WEAPON_CLASSES dict below.
}

# ── Extended weapon / explosive keyword registry (custom model classes) ───────
WEAPON_CLASSES = {
    # Firearms
    "gun", "pistol", "handgun", "rifle", "shotgun", "revolver", "firearm",
    "assault rifle", "submachine gun", "sniper", "smg", "ar", "ak47", "ak-47",
    "m4", "mp5", "uzi",
    # Bladed / sharp objects
    "knife", "blade", "machete", "sword", "dagger", "cleaver", "razor",
    "scissors", "shears", "spike", "shiv", "shank",
    # Explosive / IED
    "bomb", "explosive", "ied", "grenade", "dynamite", "c4", "tnt",
    "mine", "landmine", "detonator",
    # Fire / hazard
    "fire", "flame", "smoke", "explosion", "blast", "fireball",
    "molotov", "incendiary",
}

BLUNT_THREAT_CLASSES = {
    "baseball bat",  # COCO class 38
}

PRIORITY_CLASSES = {
    0,   # person
    24,  # backpack
    26,  # handbag
    28,  # suitcase
    38,  # baseball bat (blunt weapon)
    43,  # knife
    76,  # scissors
}


def _evaluate_threat(class_id: int, class_name: str, confidence: float, source_id: str) -> tuple[str, Optional[str], Optional[str]]:
    cname = class_name.lower().strip()
    sid = source_id.upper()

    # ── TIER 1: CRITICAL — Firearms / Explosives / Bladed Weapons ────────────
    # Match against extended weapon keyword registry
    for weapon_kw in WEAPON_CLASSES:
        if weapon_kw in cname:
            # Sub-categorize threat type
            if any(k in cname for k in ["gun", "pistol", "rifle", "shotgun", "firearm", "revolver", "smg", "ar", "ak", "m4", "mp5", "uzi"]):
                t_type = "FIREARM_DETECTED"
                t_desc = f"🔫 ARMED THREAT — FIREARM: {class_name.upper()} ({confidence:.0%} confidence)"
            elif any(k in cname for k in ["bomb", "explosive", "ied", "grenade", "dynamite", "c4", "tnt", "mine", "detonator", "molotov"]):
                t_type = "EXPLOSIVE_DEVICE_DETECTED"
                t_desc = f"💥 EXPLOSIVE THREAT — IED/DEVICE: {class_name.upper()} ({confidence:.0%} confidence)"
            elif any(k in cname for k in ["fire", "flame", "smoke", "explosion", "blast", "fireball", "incendiary"]):
                t_type = "EXPLOSION_FIRE_DETECTED"
                t_desc = f"🔥 EXPLOSION/FIRE ALERT: {class_name.upper()} ({confidence:.0%} confidence)"
            elif any(k in cname for k in ["knife", "blade", "machete", "sword", "dagger", "cleaver", "razor", "scissors", "shears", "spike", "shiv", "shank"]):
                t_type = "BLADED_WEAPON_DETECTED"
                t_desc = f"🔪 BLADED WEAPON: {class_name.upper()} ({confidence:.0%} confidence)"
            else:
                t_type = "WEAPON_DETECTED"
                t_desc = f"⚠ ARMED THREAT DETECTED: {class_name.upper()} ({confidence:.0%} confidence)"
            return ("CRITICAL_THREAT", t_type, t_desc)

    # COCO class_id direct match — knife (43), scissors (76)
    if class_id == 43:
        return ("CRITICAL_THREAT", "BLADED_WEAPON_DETECTED", f"🔪 BLADED WEAPON: KNIFE ({confidence:.0%} confidence)")
    if class_id == 76:
        return ("CRITICAL_THREAT", "BLADED_WEAPON_DETECTED", f"🔪 SHARP OBJECT: SCISSORS ({confidence:.0%} confidence)")

    # Baseball bat — blunt weapon threat
    if class_id == 38 or "baseball bat" in cname:
        return ("CRITICAL_THREAT", "BLUNT_WEAPON_DETECTED", f"🏏 BLUNT WEAPON THREAT: {class_name.upper()} ({confidence:.0%} confidence)")

    # ── TIER 2: CRITICAL — Restricted Zone Intrusion ─────────────────────────
    if "CCTV-02" in sid or "RESTRICTED" in sid or "ZONE-D" in sid or "SOURCE-C" in sid:
        if cname in {"person", "backpack", "handbag", "suitcase"}:
            return ("CRITICAL_THREAT", "RESTRICTED_ZONE_INTRUSION",
                    f"⛔ RESTRICTED ZONE BREACH: {class_name.upper()} Infiltration Detected")

    # ── TIER 3: WARNING — Unattended / Suspicious Objects ────────────────────
    if cname in {"backpack", "suitcase", "handbag"}:
        return ("WARNING", "UNATTENDED_OBJECT",
                f"⚠ SUSPICIOUS OBJECT: Unattended {class_name.upper()} — Possible IED Concealment")

    # ── TIER 4: NORMAL — Standard person tracking ─────────────────────────────
    if cname == "person":
        return ("NORMAL", "PERSON_TRACKING", "Tracked Individual")

    return ("NORMAL", None, None)
@dataclass
class Detection:
    track_id: int
    class_id: int
    class_name: str
    confidence: float
    bbox: list[float]          # [x1, y1, x2, y2] normalised 0-1
    bbox_px: list[int]         # [x1, y1, x2, y2] pixels
    frame_number: int
    timestamp_sec: float
    source_id: str
    crop_path: Optional[str] = None
    embedding: Optional[list[float]] = None  # 128-d re-ID
    threat_level: str = "NORMAL"            # "NORMAL" | "WARNING" | "CRITICAL_THREAT"
    threat_type: Optional[str] = None       # "FIREARM_DETECTED" | "BLADED_WEAPON_DETECTED" | "BLUNT_WEAPON_DETECTED" | "EXPLOSIVE_DEVICE_DETECTED" | "EXPLOSION_FIRE_DETECTED" | "WEAPON_DETECTED" | "RESTRICTED_ZONE_INTRUSION" | "UNATTENDED_OBJECT" | "PERSON_TRACKING"
    threat_description: Optional[str] = None

# ── Weapon Model singleton ──────────────────────────────────────────────────
_weapon_model: Optional[YOLO] = None
WEAPON_MODEL_PATH = Path(__file__).parent.parent.parent / "weapon_detect_yolov8n.pt"

def _get_weapon_model() -> YOLO:
    global _weapon_model
    if _weapon_model is None:
        print(f"[DETECT] Loading Weapon YOLOv8 model from {WEAPON_MODEL_PATH}")
        _weapon_model = YOLO(str(WEAPON_MODEL_PATH))
    return _weapon_model

def _iou(boxA, boxB):
    """Compute Intersection-over-Union between two boxes [x1, y1, x2, y2]."""
    xA = max(boxA[0], boxB[0])
    yA = max(boxA[1], boxB[1])
    xB = min(boxA[2], boxB[2])
    yB = min(boxA[3], boxB[3])
    interArea = max(0, xB - xA) * max(0, yB - yA)
    boxAArea = (boxA[2] - boxA[0]) * (boxA[3] - boxA[1])
    boxBArea = (boxB[2] - boxB[0]) * (boxB[3] - boxB[1])
    unionArea = boxAArea + boxBArea - interArea
    if unionArea == 0:
        return 0
    return interArea / unionArea

def _draw_weapon_box(img: np.ndarray, x1: int, y1: int, x2: int, y2: int, label: str, conf: float):
    """Draw a weapon detection box and label in RGB on the image."""
    # Red outline (RGB)
    color = (239, 68, 68)  # Tailwind red-500: #ef4444 (RGB)
    cv2.rectangle(img, (x1, y1), (x2, y2), color, 2)
    text = f"CRITICAL: {label.upper()} ({conf:.0%})"
    (tw, th), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.45, 1)
    cv2.rectangle(img, (x1, y1 - 18), (x1 + tw + 10, y1), color, -1)
    cv2.putText(img, text, (x1 + 5, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1, cv2.LINE_AA)


@dataclass
class SourceResult:
    source_id: str
    source_path: str
    file_hash: str
    fps: float
    total_frames: int
    duration_sec: float
    detections: list[Detection] = field(default_factory=list)
    processing_time_sec: float = 0.0
    annotated_video_path: Optional[str] = None
    error: Optional[str] = None


def _get_model() -> YOLO:
    global _model
    if _model is None:
        print(f"[DETECT] Loading YOLOv8 model from {MODEL_PATH}")
        _model = YOLO(str(MODEL_PATH))
    return _model


def _sha256(path: str) -> str:
    """Chain-of-custody hash — verifies footage integrity."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _save_crop(frame: np.ndarray, bbox_px: list[int], source_id: str,
               track_id: int, frame_num: int) -> Optional[str]:
    """Save detection crop for re-ID embedding computation."""
    x1, y1, x2, y2 = bbox_px
    h, w = frame.shape[:2]
    x1, y1 = max(0, x1), max(0, y1)
    x2, y2 = min(w, x2), min(h, y2)
    if x2 - x1 < 10 or y2 - y1 < 10:
        return None

    crop = frame[y1:y2, x1:x2]
    crop_dir = CROPS_DIR / source_id / f"track_{track_id:04d}"
    crop_dir.mkdir(parents=True, exist_ok=True)
    crop_path = str(crop_dir / f"frame_{frame_num:06d}.jpg")
    cv2.imwrite(crop_path, crop, [cv2.IMWRITE_JPEG_QUALITY, 85])
    return crop_path


def _naive_embedding(crop_path: str) -> list[float]:
    """
    Lightweight colour-histogram embedding (128-d).
    Replace with OSNet/torchreid when GPU available.
    Produces a consistent appearance signature for cosine similarity.
    """
    img = cv2.imread(crop_path)
    if img is None:
        return [0.0] * 128

    img_hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    emb = []
    for ch in range(3):
        hist = cv2.calcHist([img_hsv], [ch], None,
                            [32] if ch == 0 else [16],
                            [0, 180] if ch == 0 else [0, 256])
        hist = cv2.normalize(hist, hist).flatten()
        emb.extend(hist.tolist())

    # Pad/trim to exactly 128-d
    emb = (emb + [0.0] * 128)[:128]
    return emb


def process_video(source_path: str, source_id: str,
                  conf_threshold: float = 0.35,
                  sample_every_n: int = 3,
                  max_frames: int = 1800) -> SourceResult:
    """
    Run YOLOv8 + ByteTrack on a video file.

    Args:
        source_path:    Path to video file (.mp4 / .avi / .mov)
        source_id:      Unique camera/source identifier (e.g. 'Drone-01')
        conf_threshold: YOLO confidence threshold
        sample_every_n: Process every Nth frame (3 = ~10fps from 30fps source)
        max_frames:     Cap total frames processed

    Returns:
        SourceResult with all detections and per-track crops.
    """
    t_start = time.time()

    if not os.path.exists(source_path):
        return SourceResult(
            source_id=source_id, source_path=source_path,
            file_hash="", fps=0, total_frames=0, duration_sec=0,
            error=f"File not found: {source_path}"
        )

    # Chain-of-custody hash
    print(f"[DETECT] Hashing {source_id}...")
    file_hash = _sha256(source_path)
    print(f"[DETECT] SHA-256: {file_hash[:16]}...")

    cap = cv2.VideoCapture(source_path)
    if not cap.isOpened():
        return SourceResult(
            source_id=source_id, source_path=source_path,
            file_hash=file_hash, fps=0, total_frames=0, duration_sec=0,
            error="Could not open video file."
        )

    fps          = cap.get(cv2.CAP_PROP_FPS) or 25.0
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    duration_sec = total_frames / fps
    cap.release()

    print(f"[DETECT] {source_id}: {total_frames} frames @ {fps:.1f}fps ({duration_sec:.1f}s)")

    model = _get_model()
    all_detections: list[Detection] = []
    track_best_conf: dict[int, float]   = {}  # track_id → best confidence seen
    track_crop_path: dict[int, str]     = {}  # track_id → crop from best frame

    # ByteTrack tracking via persist=True
    results_gen = model.track(
        source=source_path,
        stream=True,
        tracker="bytetrack.yaml",
        conf=conf_threshold,
        iou=0.45,
        classes=list(COCO_CLASSES.keys()),
        vid_stride=sample_every_n,
        verbose=False,
    )

    # Setup annotated video output writer (H.264 MP4 for HTML5 browser compatibility)
    output_dir = Path(__file__).parent.parent.parent / "data" / "annotated_videos"
    output_dir.mkdir(parents=True, exist_ok=True)
    video_filename = f"{source_id}_{int(time.time())}.mp4"
    annotated_path = output_dir / video_filename

    writer = None

    frame_num = 0
    processed = 0

    for result in results_gen:
        if processed >= max_frames:
            break

        frame_num  = result.speed.get("inference", 0) and (processed * sample_every_n)
        ts         = (processed * sample_every_n) / fps
        frame_bgr  = result.orig_img
        img_h, img_w = frame_bgr.shape[:2]

        # Draw annotations using YOLOv8 built-in plot()
        annotated_frame_bgr = result.plot()
        annotated_frame_rgb = cv2.cvtColor(annotated_frame_bgr, cv2.COLOR_BGR2RGB)

        # Parse base model detections
        base_dets = []
        if result.boxes is not None and len(result.boxes) > 0:
            boxes = result.boxes
            ids = boxes.id
            for i, box in enumerate(boxes):
                cls_id = int(box.cls[0])
                conf = float(box.conf[0])
                xyxy = box.xyxy[0].tolist()          # pixels
                track_id = int(ids[i]) if ids is not None else -(i + 1)
                x1, y1, x2, y2 = [int(v) for v in xyxy]
                base_dets.append({
                    "cls_id": cls_id,
                    "cls_name": COCO_CLASSES.get(cls_id, f"class_{cls_id}"),
                    "conf": conf,
                    "box": [x1, y1, x2, y2],
                    "track_id": track_id
                })

        # Run specialized weapon detection model in parallel on the frame
        weapon_model_instance = _get_weapon_model()
        weapon_results = weapon_model_instance(frame_bgr, conf=min(conf_threshold, 0.30), verbose=False)

        weapon_dets = []
        WEAPON_MODEL_CLASSES = {0: "gun", 1: "explosion", 2: "grenade", 3: "knife"}
        if weapon_results and len(weapon_results) > 0 and weapon_results[0].boxes is not None:
            w_boxes = weapon_results[0].boxes
            for i, box in enumerate(w_boxes):
                cls_id = int(box.cls[0])
                conf = float(box.conf[0])
                xyxy = box.xyxy[0].tolist()          # pixels
                x1, y1, x2, y2 = [int(v) for v in xyxy]
                cls_name = WEAPON_MODEL_CLASSES.get(cls_id, f"weapon_class_{cls_id}")
                # Assign a unique negative track ID to avoid collision with base tracks
                weapon_dets.append({
                    "cls_id": cls_id,
                    "cls_name": cls_name,
                    "conf": conf,
                    "box": [x1, y1, x2, y2],
                    "track_id": -200 - i
                })

        # Deduplicate weapon detections against base model detections (e.g. knife vs knife)
        final_weapon_dets = []
        for w_det in weapon_dets:
            dup = False
            for b_det in base_dets:
                # If weapon type matches (e.g. both knife) or if weapon model gun overlaps with suitcase/person
                is_same_type = (w_det["cls_name"] == "knife" and b_det["cls_name"] == "knife")
                is_overlap = _iou(w_det["box"], b_det["box"]) > 0.45
                if is_overlap:
                    if is_same_type:
                        if b_det["conf"] >= w_det["conf"]:
                            dup = True
                        else:
                            # Base knife is lower confidence; replace it
                            if b_det in base_dets:
                                base_dets.remove(b_det)
                        break
                    elif b_det["cls_name"] in ["backpack", "handbag", "suitcase"]:
                        # Unattended bags can be explosive, but if weapon model says 'grenade' or 'explosion'
                        # or 'gun' with high confidence, let it co-exist or override if IoU is very high.
                        pass
            if not dup:
                final_weapon_dets.append(w_det)

        # Draw specialized weapon detection overlays on the output frame
        for w_det in final_weapon_dets:
            x1, y1, x2, y2 = w_det["box"]
            _draw_weapon_box(annotated_frame_rgb, x1, y1, x2, y2, w_det["cls_name"], w_det["conf"])

        # Write frame to output video
        if writer is None:
            out_fps = max(1.0, fps / sample_every_n)
            writer = imageio.get_writer(str(annotated_path), fps=out_fps, codec='libx264', pixelformat='yuv420p', macro_block_size=1)

        if writer:
            writer.append_data(annotated_frame_rgb)

        # Process and record both base and weapon detections
        for det_info in (base_dets + final_weapon_dets):
            x1, y1, x2, y2 = det_info["box"]
            bbox_norm = [
                x1 / img_w, y1 / img_h,
                x2 / img_w, y2 / img_h
            ]

            track_id = det_info["track_id"]
            conf = det_info["conf"]

            # Save best-confidence crop per track
            if conf > track_best_conf.get(track_id, 0.0):
                track_best_conf[track_id] = conf
                crop_p = _save_crop(frame_bgr, [x1, y1, x2, y2],
                                    source_id, track_id, processed * sample_every_n)
                if crop_p:
                    track_crop_path[track_id] = crop_p

            t_level, t_type, t_desc = _evaluate_threat(det_info["cls_id"], det_info["cls_name"], conf, source_id)

            det = Detection(
                track_id=track_id,
                class_id=det_info["cls_id"],
                class_name=det_info["cls_name"],
                confidence=round(conf, 4),
                bbox=bbox_norm,
                bbox_px=[x1, y1, x2, y2],
                frame_number=processed * sample_every_n,
                timestamp_sec=round(ts, 3),
                source_id=source_id,
                crop_path=track_crop_path.get(track_id),
                threat_level=t_level,
                threat_type=t_type,
                threat_description=t_desc,
            )
            all_detections.append(det)

        processed += 1
        if processed % 50 == 0:
            print(f"[DETECT] {source_id}: processed {processed} frames, "
                  f"{len(all_detections)} detections so far")

    if writer:
        writer.close()

    # Compute lightweight embeddings for unique tracks
    print(f"[DETECT] {source_id}: Computing embeddings for {len(track_crop_path)} tracks...")
    track_emb: dict[int, list[float]] = {}
    for tid, crop_p in track_crop_path.items():
        track_emb[tid] = _naive_embedding(crop_p)

    # Attach embeddings to detections
    for det in all_detections:
        det.embedding = track_emb.get(det.track_id)

    proc_time = time.time() - t_start
    print(f"[DETECT] {source_id}: DONE — {len(all_detections)} detections, "
          f"{len(track_crop_path)} tracks, {proc_time:.1f}s")

    return SourceResult(
        source_id=source_id,
        source_path=source_path,
        file_hash=file_hash,
        fps=fps,
        total_frames=total_frames,
        duration_sec=round(duration_sec, 2),
        detections=all_detections,
        processing_time_sec=round(proc_time, 2),
        annotated_video_path=str(annotated_path) if annotated_path.exists() else None,
    )


def process_frame(frame_bgr: np.ndarray, source_id: str,
                  frame_number: int = 0,
                  conf_threshold: float = 0.40) -> list[Detection]:
    """
    Run YOLOv8 base + weapon models on a single frame (for live streaming).
    Returns list of detections with threat analysis.
    """
    model = _get_model()
    img_h, img_w = frame_bgr.shape[:2]

    # Run base model
    results = model(frame_bgr, conf=conf_threshold,
                    classes=list(COCO_CLASSES.keys()), verbose=False)

    base_dets = []
    if results and len(results) > 0 and results[0].boxes is not None:
        for box in results[0].boxes:
            cls_id = int(box.cls[0])
            conf = float(box.conf[0])
            xyxy = box.xyxy[0].tolist()
            x1, y1, x2, y2 = [int(v) for v in xyxy]
            base_dets.append({
                "cls_id": cls_id,
                "cls_name": COCO_CLASSES.get(cls_id, f"class_{cls_id}"),
                "conf": conf,
                "box": [x1, y1, x2, y2]
            })

    # Run weapon model
    weapon_model_instance = _get_weapon_model()
    weapon_results = weapon_model_instance(frame_bgr, conf=min(conf_threshold, 0.30), verbose=False)

    weapon_dets = []
    WEAPON_MODEL_CLASSES = {0: "gun", 1: "explosion", 2: "grenade", 3: "knife"}
    if weapon_results and len(weapon_results) > 0 and weapon_results[0].boxes is not None:
        for box in weapon_results[0].boxes:
            cls_id = int(box.cls[0])
            conf = float(box.conf[0])
            xyxy = box.xyxy[0].tolist()
            x1, y1, x2, y2 = [int(v) for v in xyxy]
            cls_name = WEAPON_MODEL_CLASSES.get(cls_id, f"weapon_class_{cls_id}")
            weapon_dets.append({
                "cls_id": cls_id,
                "cls_name": cls_name,
                "conf": conf,
                "box": [x1, y1, x2, y2]
            })

    # Deduplicate weapon detections against base model detections
    final_weapon_dets = []
    for w_det in weapon_dets:
        dup = False
        for b_det in base_dets:
            is_same_type = (w_det["cls_name"] == "knife" and b_det["cls_name"] == "knife")
            is_overlap = _iou(w_det["box"], b_det["box"]) > 0.45
            if is_overlap:
                if is_same_type:
                    if b_det["conf"] >= w_det["conf"]:
                        dup = True
                    else:
                        if b_det in base_dets:
                            base_dets.remove(b_det)
                    break
        if not dup:
            final_weapon_dets.append(w_det)

    detections = []
    for det_info in (base_dets + final_weapon_dets):
        x1, y1, x2, y2 = det_info["box"]
        conf = det_info["conf"]
        cls_id = det_info["cls_id"]
        cls_name = det_info["cls_name"]

        t_level, t_type, t_desc = _evaluate_threat(cls_id, cls_name, conf, source_id)

        detections.append(Detection(
            track_id=-1,
            class_id=cls_id,
            class_name=cls_name,
            confidence=round(conf, 4),
            bbox=[x1/img_w, y1/img_h, x2/img_w, y2/img_h],
            bbox_px=[x1, y1, x2, y2],
            frame_number=frame_number,
            timestamp_sec=0.0,
            source_id=source_id,
            threat_level=t_level,
            threat_type=t_type,
            threat_description=t_desc,
        ))

    return detections
