"""
SENTINEL-X Module 2 — CONNECT
Cross-source entity linking via 3-signal scoring + Hungarian assignment.

Three signals:
  S(A,B) = w1·Appearance(A,B) + w2·TemporalFeasibility(A,B) + w3·SpatialAdjacency(i,j)
           - penalty(constraint_violations)
"""

import json
import numpy as np
import networkx as nx
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .detect import Detection, SourceResult

# ── Zone topology ─────────────────────────────────────────────────────────────
ZONE_GRAPH_PATH = Path(__file__).parent.parent / "mock_data" / "zone_topology.json"

# Default zone adjacency (overridden by zone_topology.json)
DEFAULT_ZONES = {
    "Perimeter-North": {"Perimeter-East": 120, "Gate-A": 90},
    "Perimeter-East":  {"Perimeter-North": 120, "Perimeter-South": 150, "Zone-B": 200},
    "Perimeter-South": {"Perimeter-East": 150, "Gate-B": 80},
    "Gate-A":          {"Perimeter-North": 90, "Zone-A": 60},
    "Gate-B":          {"Perimeter-South": 80, "Zone-B": 100},
    "Zone-A":          {"Gate-A": 60, "Zone-B": 180, "Building-Entrance": 70},
    "Zone-B":          {"Zone-A": 180, "Gate-B": 100, "Perimeter-East": 200},
    "Building-Entrance": {"Zone-A": 70, "Zone-C": 50},
    "Zone-C":          {"Building-Entrance": 50},
}

WALKING_SPEED_MPS = 1.4   # m/s average walking speed
LINK_THRESHOLD    = 0.45  # minimum score to propose a link
CONFIRM_THRESHOLD = 0.70  # auto-confirmed (investigator still sees it)

# Signal weights
W_APPEARANCE = 0.50
W_TEMPORAL   = 0.30
W_SPATIAL    = 0.20

# Cross-view penalty factors (drone→body-cam similarity is systematically lower)
VIEW_PAIR_CALIBRATION = {
    ("drone",  "bodycam"): 0.82,
    ("bodycam","drone"):   0.82,
    ("drone",  "robot"):   0.88,
    ("robot",  "drone"):   0.88,
    ("bodycam","robot"):   0.92,
    ("robot",  "bodycam"): 0.92,
}


@dataclass
class TrackSignature:
    """Aggregated appearance signature for one intra-camera track."""
    source_id: str
    track_id: int
    class_name: str
    embedding: list[float]         # mean of top-k confident crops
    first_seen: float              # timestamp (seconds)
    last_seen: float
    zone: Optional[str]            # mapped zone (from camera metadata)
    peak_confidence: float
    detections: list[Detection]    # all detections for this track


@dataclass
class EntityLink:
    """Proposed link between two cross-source tracks."""
    source_a: str
    track_a: int
    source_b: str
    track_b: int
    score: float
    appearance_score: float
    temporal_score: float
    spatial_score: float
    delta_t: float                 # seconds between tracks
    min_travel_time: float         # physical minimum (distance / speed)
    zone_a: Optional[str]
    zone_b: Optional[str]
    status: str                    # "confirmed" | "proposed" | "low_confidence"
    constraint_violations: list[str] = field(default_factory=list)


@dataclass
class EntityChain:
    """One physical actor linked across cameras."""
    chain_id: str
    links: list[EntityLink]
    tracks: list[TrackSignature]
    chain_confidence: float
    flagged: bool = False          # True if transitivity conflict detected


def _load_zone_graph() -> dict:
    try:
        with open(ZONE_GRAPH_PATH) as f:
            data = json.load(f)
            return data.get("adjacency", DEFAULT_ZONES)
    except Exception:
        return DEFAULT_ZONES


def _min_travel_time(zone_a: Optional[str], zone_b: Optional[str],
                     zone_graph: dict) -> float:
    """Shortest-path walking time between zones (seconds). Returns inf if unreachable."""
    if not zone_a or not zone_b or zone_a == zone_b:
        return 0.0

    G = nx.Graph()
    for z, neighbours in zone_graph.items():
        for n, dist in neighbours.items():
            G.add_edge(z, n, weight=dist)

    try:
        dist_m = nx.shortest_path_length(G, zone_a, zone_b, weight="weight")
        return dist_m / WALKING_SPEED_MPS
    except nx.NetworkXNoPath:
        return float("inf")
    except nx.NodeNotFound:
        return 60.0  # unknown zone — moderate penalty


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    va, vb = np.array(a), np.array(b)
    denom = (np.linalg.norm(va) * np.linalg.norm(vb))
    if denom < 1e-9:
        return 0.0
    return float(np.dot(va, vb) / denom)


def _view_type(source_id: str) -> str:
    sid = source_id.lower()
    if "drone" in sid:      return "drone"
    if "body" in sid or "officer" in sid: return "bodycam"
    if "robot" in sid:      return "robot"
    return "cctv"


def _map_source_to_zone(source_id: str) -> str:
    sid = source_id.upper()
    if "DRONE" in sid or "CCTV-01" in sid:
        return "ZONE-A"
    if "ROBOT" in sid:
        return "ZONE-B"
    if "BODY" in sid or "OFFICER" in sid:
        return "ZONE-C"
    if "CCTV-02" in sid:
        return "ZONE-D"
    return "ZONE-A"

def _build_signatures(results: list[SourceResult]) -> list[TrackSignature]:
    """
    Aggregate detections into per-track signatures.
    Uses mean embedding of top-5 confident crops per track.
    """
    signatures = []

    for src in results:
        # Group detections by track_id
        tracks: dict[int, list[Detection]] = {}
        for det in src.detections:
            if det.class_name == "person":  # focus on persons for re-ID
                tracks.setdefault(det.track_id, []).append(det)

        for tid, dets in tracks.items():
            if not dets:
                continue

            # Sort by confidence, take top-5
            top_k = sorted(dets, key=lambda d: d.confidence, reverse=True)[:5]

            # Mean embedding
            embeds = [d.embedding for d in top_k if d.embedding]
            if embeds:
                mean_emb = np.mean(embeds, axis=0).tolist()
            else:
                mean_emb = [0.0] * 128

            times = [d.timestamp_sec for d in dets]
            sig = TrackSignature(
                source_id=src.source_id,
                track_id=tid,
                class_name=dets[0].class_name,
                embedding=mean_emb,
                first_seen=min(times),
                last_seen=max(times),
                zone=_map_source_to_zone(src.source_id),
                peak_confidence=max(d.confidence for d in dets),
                detections=dets,
            )
            signatures.append(sig)

    return signatures


def _score_link(sig_a: TrackSignature, sig_b: TrackSignature,
                zone_graph: dict) -> EntityLink:
    """Compute the 3-signal link score between two cross-source tracks."""

    # 1. Appearance score (cosine similarity with cross-view calibration)
    app_raw = _cosine_similarity(sig_a.embedding, sig_b.embedding)
    view_a  = _view_type(sig_a.source_id)
    view_b  = _view_type(sig_b.source_id)
    calib   = VIEW_PAIR_CALIBRATION.get((view_a, view_b), 1.0)
    app_score = min(1.0, app_raw / calib)

    # 2. Temporal feasibility score
    # Not raw proximity — physically possible transition check
    delta_t       = abs(sig_b.first_seen - sig_a.last_seen)
    min_travel    = _min_travel_time(sig_a.zone, sig_b.zone, zone_graph)
    violations    = []

    if min_travel == float("inf"):
        # Zones not connected — spatial impossibility
        temp_score = 0.0
        violations.append("zones_not_connected")
    elif delta_t < min_travel:
        # Physically impossible — person can't travel that fast
        temp_score = 0.0
        violations.append(f"temporal_impossible: Δt={delta_t:.1f}s < min={min_travel:.1f}s")
    else:
        # Feasible — score based on how plausibly timed the transition is
        # Peak score at min_travel, decaying for very long gaps
        excess = delta_t - min_travel
        temp_score = float(np.exp(-excess / 120.0))  # 120s decay constant

    # 3. Spatial adjacency score
    if sig_a.zone and sig_b.zone:
        if sig_a.zone == sig_b.zone:
            spatial_score = 1.0
        else:
            G = nx.Graph()
            for z, nb in zone_graph.items():
                for n, d in nb.items():
                    G.add_edge(z, n, weight=d)
            try:
                path_len = nx.shortest_path_length(G, sig_a.zone, sig_b.zone)
                # Adjacent = 1 hop → 1.0; 2 hops → 0.6; 3 hops → 0.3
                spatial_score = max(0.0, 1.0 - (path_len - 1) * 0.35)
            except Exception:
                spatial_score = 0.3
    else:
        spatial_score = 0.5  # unknown zone — neutral

    # Combined score
    total = (W_APPEARANCE * app_score
             + W_TEMPORAL  * temp_score
             + W_SPATIAL   * spatial_score)

    # Constraint violation penalty
    total -= 0.25 * len(violations)
    total = max(0.0, min(1.0, total))

    if total >= CONFIRM_THRESHOLD:
        status = "confirmed"
    elif total >= LINK_THRESHOLD:
        status = "proposed"
    else:
        status = "low_confidence"

    return EntityLink(
        source_a=sig_a.source_id,  track_a=sig_a.track_id,
        source_b=sig_b.source_id,  track_b=sig_b.track_id,
        score=round(total, 4),
        appearance_score=round(app_score, 4),
        temporal_score=round(temp_score, 4),
        spatial_score=round(spatial_score, 4),
        delta_t=round(delta_t, 2),
        min_travel_time=round(min_travel if min_travel != float("inf") else -1, 2),
        zone_a=sig_a.zone,
        zone_b=sig_b.zone,
        status=status,
        constraint_violations=violations,
    )


def link_sources(results: list[SourceResult]) -> tuple[list[EntityChain], list[EntityLink]]:
    """
    Run full cross-source linking pipeline.

    Steps:
      1. Build per-track appearance signatures
      2. Score all cross-source track pairs
      3. Greedy threshold pruning (mutual exclusion)
      4. Merge into entity chains via connected components
      5. Transitivity check — flag contradicted chains

    Returns:
        (entity_chains, all_links)
    """
    zone_graph = _load_zone_graph()
    signatures = _build_signatures(results)

    print(f"[CONNECT] Built {len(signatures)} track signatures across "
          f"{len(results)} sources")

    if len(signatures) < 2:
        return [], []

    # Score all cross-source pairs
    all_links: list[EntityLink] = []
    source_ids = [s.source_id for s in results]

    for i, sig_a in enumerate(signatures):
        for sig_b in signatures[i+1:]:
            if sig_a.source_id == sig_b.source_id:
                continue   # skip intra-source pairs

            link = _score_link(sig_a, sig_b, zone_graph)
            all_links.append(link)

    # Keep only links above threshold
    valid_links = [l for l in all_links if l.score >= LINK_THRESHOLD]
    print(f"[CONNECT] {len(all_links)} pairs scored, "
          f"{len(valid_links)} above threshold {LINK_THRESHOLD}")

    # Build link graph for component merging
    G = nx.Graph()
    sig_map = {(s.source_id, s.track_id): s for s in signatures}
    for s in signatures:
        G.add_node((s.source_id, s.track_id))

    for link in valid_links:
        G.add_edge(
            (link.source_a, link.track_a),
            (link.source_b, link.track_b),
            score=link.score,
            link=link,
        )

    # Connected components = entity chains
    chains: list[EntityChain] = []
    for comp_idx, component in enumerate(nx.connected_components(G)):
        comp_sigs = [sig_map[node] for node in component if node in sig_map]
        comp_links = [
            G[u][v]["link"]
            for u, v in G.subgraph(component).edges()
        ]

        if not comp_links:
            continue

        chain_conf = round(np.mean([l.score for l in comp_links]), 4)

        # Transitivity check: flag if any two accepted links contradict
        flagged = False
        src_presence: dict[str, list[TrackSignature]] = {}
        for sig in comp_sigs:
            src_presence.setdefault(sig.source_id, []).append(sig)

        for src_id, sigs_in_src in src_presence.items():
            if len(sigs_in_src) > 1:
                # Same chain claims >1 track in same source — contradiction
                flagged = True
                print(f"[CONNECT] Chain {comp_idx}: transitivity conflict "
                      f"in {src_id} — flagged as low-confidence")
                break

        chains.append(EntityChain(
            chain_id=f"CHAIN-{comp_idx+1:03d}",
            links=comp_links,
            tracks=comp_sigs,
            chain_confidence=chain_conf,
            flagged=flagged,
        ))

    chains.sort(key=lambda c: c.chain_confidence, reverse=True)
    print(f"[CONNECT] {len(chains)} entity chains assembled")
    return chains, all_links
