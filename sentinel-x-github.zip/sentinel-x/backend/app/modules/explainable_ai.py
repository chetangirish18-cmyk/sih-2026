"""
SENTINEL-X Explainable AI Module
Generates transparent, audit-ready explanations for detected threats & linked incident chains.
"""
from typing import Dict, Any

class ExplainableAIModule:
    """
    Constructs explainability cards answering:
    - What happened?
    - Where did it occur?
    - When did it take place?
    - Why was it flagged as abnormal?
    - What is the Confidence & Threat Risk Score?
    - Which 10-30s video clip snippet serves as verifiable evidence?
    """
    def generate_explanation(self, event: Dict[str, Any]) -> Dict[str, Any]:
        exp = event.get("explanation", {})
        risk_score = event.get("risk_score", 75)
        
        risk_badge = "LOW"
        if risk_score >= 85:
            risk_badge = "CRITICAL THREAT"
        elif risk_score >= 70:
            risk_badge = "HIGH RISK"
        elif risk_score >= 50:
            risk_badge = "MEDIUM RISK"

        return {
            "event_id": event.get("event_id"),
            "camera_id": event.get("camera_id"),
            "camera_name": event.get("camera_name"),
            "what": exp.get("what", f"Detected {event.get('detection_label', 'activity')}"),
            "where": exp.get("where", f"Zone {event.get('zone_id', 'Unknown')} ({event.get('zone_name', '')})"),
            "when": exp.get("when", event.get("timestamp", "02:14:00 UTC")),
            "why_abnormal": exp.get("why_abnormal", "Observed pattern deviates from standard operational baselines."),
            "confidence_pct": int(event.get("confidence", 0.90) * 100),
            "risk_score": risk_score,
            "risk_badge": risk_badge,
            "evidence_clip": {
                "duration_seconds": 20,
                "timestamp_range": exp.get("evidence_clip_seconds", "02:14:00 - 02:14:20"),
                "status": "READY_FOR_OPERATOR_REVIEW"
            }
        }

explainable_ai_engine = ExplainableAIModule()
