"""
SENTINEL-X — Telegram Alert Module
===================================
Sends SHORT threat-moment clips (±3 sec around each detection) and a
location pin to @NSG_1BOT whenever HIGH/CRITICAL threats are detected.

Public API:
    send_threat_alert(source_id, detections, annotated_video_path,
                      location_name, lat, lon) -> bool
"""

import os
import sys
import time
import json
import logging
import tempfile
from pathlib import Path
from typing import Optional

import cv2
import requests

logger = logging.getLogger("sentinel_x.telegram")

# ── Bot Configuration ─────────────────────────────────────────────────────────
BOT_TOKEN = os.environ.get(
    "TELEGRAM_BOT_TOKEN",
    "8607649259:AAGJmRH7giDD4grIW2B9LIpQ01P2A55IOmM",
)
CHAT_ID  = os.environ.get("TELEGRAM_CHAT_ID", "")
BASE_URL = f"https://api.telegram.org/bot{BOT_TOKEN}"

# Only these threat levels fire an alert  (must match detect.py _evaluate_threat output)
ALERT_LEVELS = {"HIGH", "CRITICAL", "CRITICAL_THREAT", "WARNING"}

# Clip settings
CLIP_PAD_SEC   = 3      # seconds before/after the threat frame
MAX_CLIP_SEC   = 8      # hard cap per clip so it stays tiny
MAX_CLIPS_SENT = 3      # send at most this many clips per job (avoid flood)

_THREAT_EMOJI = {
    "gun":       "🔫",
    "knife":     "🔪",
    "grenade":   "💣",
    "explosion": "💥",
    "weapon":    "⚠️",
}

# ── Persisted config ──────────────────────────────────────────────────────────
_config_path = Path(__file__).parent.parent.parent / "data" / "telegram_config.json"

def _load_config() -> dict:
    try:
        if _config_path.exists():
            return json.loads(_config_path.read_text())
    except Exception:
        pass
    return {}

def _save_config(cfg: dict):
    _config_path.parent.mkdir(parents=True, exist_ok=True)
    _config_path.write_text(json.dumps(cfg, indent=2))

def get_chat_id() -> str:
    if CHAT_ID:
        return CHAT_ID
    return _load_config().get("chat_id", "")

def set_chat_id(chat_id: str):
    cfg = _load_config()
    cfg["chat_id"] = chat_id
    _save_config(cfg)
    logger.info(f"[TelegramBot] Chat ID set to {chat_id}")


# ── Telegram API helpers ──────────────────────────────────────────────────────

def _post(endpoint: str, **kwargs) -> dict:
    try:
        resp = requests.post(f"{BASE_URL}/{endpoint}", timeout=60, **kwargs)
        return resp.json()
    except Exception as e:
        logger.error(f"[TelegramBot] POST {endpoint} failed: {e}")
        return {"ok": False, "error": str(e)}

def _get(endpoint: str, **kwargs) -> dict:
    try:
        resp = requests.get(f"{BASE_URL}/{endpoint}", timeout=15, **kwargs)
        return resp.json()
    except Exception as e:
        return {"ok": False, "error": str(e)}

def _send_message(chat_id: str, text: str) -> dict:
    return _post("sendMessage", json={
        "chat_id": chat_id, "text": text, "parse_mode": "HTML"
    })

def _send_video_file(chat_id: str, video_path: str, caption: str) -> dict:
    with open(video_path, "rb") as vf:
        return _post(
            "sendVideo",
            data={"chat_id": chat_id, "caption": caption,
                  "parse_mode": "HTML", "supports_streaming": "true"},
            files={"video": vf},
        )

def _send_location(chat_id: str, lat: float, lon: float) -> dict:
    return _post("sendLocation",
                 json={"chat_id": chat_id, "latitude": lat, "longitude": lon})


# ── Clip extractor ────────────────────────────────────────────────────────────

def _extract_clip(
    video_path: str,
    threat_ts: float,
    fps: float,
    total_frames: int,
    out_path: str,
) -> bool:
    """
    Cut a short H.264 clip from `video_path` centred on `threat_ts` seconds.
    """
    try:
        import imageio
        start_ts = max(0.0, threat_ts - CLIP_PAD_SEC)
        duration = min(total_frames / fps if fps > 0 else 99, threat_ts + CLIP_PAD_SEC)
        end_ts   = min(duration, start_ts + MAX_CLIP_SEC)

        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            logger.warning(f"[Clip] Cannot open {video_path}")
            return False

        src_fps     = cap.get(cv2.CAP_PROP_FPS) or fps or 25.0
        src_w       = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        src_h       = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        start_frame = int(start_ts * src_fps)
        end_frame   = int(end_ts   * src_fps)

        cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)

        writer = imageio.get_writer(out_path, fps=src_fps, codec='libx264', pixelformat='yuv420p', macro_block_size=1)

        frame_idx = start_frame
        while frame_idx < end_frame:
            ok, frame = cap.read()
            if not ok:
                break
            # cv2 reads BGR; convert to RGB for imageio
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            writer.append_data(frame_rgb)
            frame_idx += 1

        cap.release()
        writer.close()

        size = Path(out_path).stat().st_size
        if size < 1000:
            logger.warning(f"[Clip] Output too small ({size}B), skipping")
            return False

        logger.info(f"[Clip] {start_ts:.1f}s-{end_ts:.1f}s → {out_path} ({size//1024}KB)")
        return True

    except Exception as e:
        logger.error(f"[Clip] Extraction error: {e}")
        return False



def _pick_threat_timestamps(detections: list[dict]) -> list[float]:
    """
    From a list of detections, pick distinct timestamps to clip around.
    Clusters detections within 4 seconds together so we don't spam clips.
    Returns at most MAX_CLIPS_SENT timestamps.
    """
    CLUSTER_GAP = 4.0   # merge threats within 4 s of each other

    threat_times = sorted(set(
        float(d.get("timestamp_sec", 0))
        for d in detections
        if d.get("threat_level") in ALERT_LEVELS
        and d.get("timestamp_sec") is not None
    ))

    if not threat_times:
        # fall back: use frame_number / 25 fps estimate
        threat_times = sorted(set(
            float(d.get("frame_number", 0)) / 25.0
            for d in detections
            if d.get("threat_level") in ALERT_LEVELS
        ))

    # Cluster
    clusters: list[float] = []
    last = -999.0
    for t in threat_times:
        if t - last >= CLUSTER_GAP:
            clusters.append(t)
            last = t

    return clusters[:MAX_CLIPS_SENT]


# ── Caption builder ───────────────────────────────────────────────────────────

def _build_caption(
    source_id: str,
    detections: list[dict],
    clip_ts: float,
    location_name: str,
    lat: Optional[float],
    lon: Optional[float],
    clip_index: int,
    total_clips: int,
) -> str:
    now = time.strftime("%H:%M:%S UTC", time.gmtime())

    # threats near this clip
    window = CLIP_PAD_SEC * 2 + MAX_CLIP_SEC
    nearby = [
        d for d in detections
        if d.get("threat_level") in ALERT_LEVELS
        and abs(float(d.get("timestamp_sec") or
                      float(d.get("frame_number", 0)) / 25.0) - clip_ts) <= window
    ] or detections

    counts: dict[str, int] = {}
    for d in nearby:
        t = (d.get("threat_type") or d.get("class_name", "?")).lower()
        counts[t] = counts.get(t, 0) + 1

    threats_str = "  ".join(
        f"{_THREAT_EMOJI.get(k,'⚠️')}{k.upper()}x{v}" for k, v in counts.items()
    ) or "⚠️ THREAT"

    gps_str = f"{lat:.4f}N, {lon:.4f}E" if lat and lon else location_name
    clip_label = f"[{clip_index}/{total_clips}]" if total_clips > 1 else ""

    return (
        f"🚨 <b>THREAT DETECTED</b> {clip_label}\n"
        f"📡 {source_id} | ⏱ T+{clip_ts:.1f}s | 🕐 {now}\n"
        f"📍 {location_name}\n"
        f"🗺 <code>{gps_str}</code>\n"
        f"{threats_str}\n"
        f"<i>NSG SENTINEL-X</i>"
    )


# ── Public API ────────────────────────────────────────────────────────────────

def send_threat_alert(
    source_id: str,
    detections: list[dict],
    annotated_video_path: Optional[str] = None,
    location_name: str = "Classified Zone",
    lat: Optional[float] = None,
    lon: Optional[float] = None,
) -> bool:
    """
    Main entry point called after every detection job.
    - Filters for HIGH/CRITICAL threats only
    - Extracts SHORT clips (±3s) around each threat moment
    - Sends clips + location pin to Telegram
    Returns True if at least one alert was sent.
    """
    chat_id = get_chat_id()
    if not chat_id:
        logger.warning("[TelegramBot] No chat_id — run /api/telegram/discover first")
        return False

    threat_detections = [
        d for d in detections
        if d.get("threat_level") in ALERT_LEVELS
    ]
    if not threat_detections:
        logger.info(f"[TelegramBot] No HIGH/CRITICAL threats in {source_id} — skip")
        return False

    # ── No video: text-only alert ─────────────────────────────────────────────
    if not annotated_video_path or not Path(annotated_video_path).exists():
        caption = _build_caption(
            source_id, threat_detections, 0.0,
            location_name, lat, lon, 1, 1,
        )
        _send_message(chat_id, caption)
        if lat and lon:
            _send_location(chat_id, lat, lon)
        return True

    # ── Pick timestamps & extract clips ───────────────────────────────────────
    clip_timestamps = _pick_threat_timestamps(threat_detections)
    if not clip_timestamps:
        clip_timestamps = [0.0]

    # Estimate fps/total_frames from video
    try:
        cap  = cv2.VideoCapture(annotated_video_path)
        fps  = cap.get(cv2.CAP_PROP_FPS) or 25.0
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        cap.release()
    except Exception:
        fps, total_frames = 25.0, 0

    sent_count = 0
    tmp_dir = Path(tempfile.mkdtemp(prefix="sentinel_clip_"))

    for i, ts in enumerate(clip_timestamps, start=1):
        clip_path = str(tmp_dir / f"clip_{i}_{int(ts)}s.mp4")
        ok = _extract_clip(annotated_video_path, ts, fps, total_frames, clip_path)

        caption = _build_caption(
            source_id, threat_detections, ts,
            location_name, lat, lon, i, len(clip_timestamps),
        )

        if ok:
            result = _send_video_file(chat_id, clip_path, caption)
        else:
            result = _send_message(chat_id, caption)

        if result.get("ok"):
            sent_count += 1
            logger.info(f"[TelegramBot] Clip {i}/{len(clip_timestamps)} sent (T+{ts:.1f}s)")
        else:
            logger.error(f"[TelegramBot] Failed clip {i}: {result}")

    # ── Location pin after last clip ──────────────────────────────────────────
    if sent_count > 0 and lat is not None and lon is not None:
        _send_location(chat_id, lat, lon)

    # ── Cleanup temp clips ────────────────────────────────────────────────────
    try:
        for f in tmp_dir.iterdir():
            f.unlink()
        tmp_dir.rmdir()
    except Exception:
        pass

    logger.info(f"[TelegramBot] Done — {sent_count}/{len(clip_timestamps)} clips sent for {source_id}")
    return sent_count > 0


# ── Bot management helpers ────────────────────────────────────────────────────

def verify_bot() -> dict:
    return _get("getMe")

def get_updates() -> dict:
    return _get("getUpdates")
