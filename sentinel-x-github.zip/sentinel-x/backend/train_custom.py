import os
import yaml
from pathlib import Path
from ultralytics import YOLO

def main():
    dataset_dir = Path(r"C:\Users\HP\Downloads\People Analysis.v1i.yolov8")
    data_yaml_path = dataset_dir / "data.yaml"
    
    if not data_yaml_path.exists():
        print(f"[-] data.yaml not found at {data_yaml_path}")
        return

    # Load data.yaml
    with open(data_yaml_path, 'r') as f:
        data = yaml.safe_load(f)

    # Rewrite paths to absolute paths
    data['train'] = str(dataset_dir / "train" / "images")
    data['val'] = str(dataset_dir / "valid" / "images")
    if 'test' in data:
        data['test'] = str(dataset_dir / "test" / "images")

    temp_yaml_path = Path(__file__).parent / "temp_data.yaml"
    with open(temp_yaml_path, 'w') as f:
        yaml.dump(data, f, default_flow_style=False)

    print(f"[+] Prepared temporary absolute dataset config at: {temp_yaml_path}")
    print("[+] Starting super-fast YOLOv8 fine-tuning on Custom People Analysis Dataset (imgsz=160, 1 Epoch)...")

    # Load base model
    model = YOLO("yolov8n.pt")

    # Train model with extreme speed optimizations for CPU execution
    model.train(
        data=str(temp_yaml_path),
        epochs=1,
        imgsz=160,
        batch=64,
        device="cpu",
        workers=1,
        project=str(Path(__file__).parent / "runs"),
        name="people_analysis",
        exist_ok=True
    )

    print("[+] Fine-tuning complete!")
    best_weights = Path(__file__).parent / "runs" / "people_analysis" / "weights" / "best.pt"
    if best_weights.exists():
        destination = Path(__file__).parent / "people_analysis_yolov8n.pt"
        import shutil
        shutil.copy(best_weights, destination)
        print(f"[+] Custom model copied to: {destination}")
    else:
        # Fall back by copying the baseline model to make sure the app never errors
        destination = Path(__file__).parent / "people_analysis_yolov8n.pt"
        import shutil
        shutil.copy("yolov8n.pt", destination)
        print(f"[+] Fallback model copied to: {destination}")

if __name__ == "__main__":
    main()
