import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
import logging, requests
logging.basicConfig(level=logging.INFO)

from app.modules.telegram_notifier import send_threat_alert, ALERT_LEVELS

mock_detections = [
    {'threat_level': 'CRITICAL_THREAT', 'threat_type': 'gun',   'class_name': 'gun',   'confidence': 0.91, 'timestamp_sec': 2.0, 'frame_number': 50},
    {'threat_level': 'CRITICAL_THREAT', 'threat_type': 'knife', 'class_name': 'knife', 'confidence': 0.87, 'timestamp_sec': 6.5, 'frame_number': 162},
    {'threat_level': 'NORMAL',          'threat_type': None,     'class_name': 'person','confidence': 0.72, 'timestamp_sec': 1.0, 'frame_number': 25},
]

print('ALERT_LEVELS:', ALERT_LEVELS)
threat_dets = [d for d in mock_detections if d['threat_level'] in ALERT_LEVELS]
print('Threats that fire:', len(threat_dets))

gps = requests.get('http://ip-api.com/json/', timeout=8).json()
lat = gps['lat']
lon = gps['lon']
city = gps['city'] + ', ' + gps['regionName'] + ', ' + gps['country']
print('GPS:', lat, lon, city)

video = r'C:\Users\HP\.gemini\antigravity\scratch\sentinel-x\backend\data\annotated_videos\CCTV-02_1787956900.mp4'

sent = send_threat_alert(
    source_id='CCTV-02 (Restricted Entry)',
    detections=mock_detections,
    annotated_video_path=video,
    location_name=city,
    lat=lat,
    lon=lon,
)
print('Result:', 'SENT' if sent else 'FAILED')
