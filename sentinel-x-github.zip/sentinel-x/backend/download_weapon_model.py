"""
download_weapon_model.py
Downloads a pre-trained YOLOv8 weapon detection model from Hugging Face.
Model: keremberke/yolov8m-weapon-detection
Classes: Knife, Pistol, Rifle, Shotgun, SMG (submachine gun)
"""

import sys
from pathlib import Path

TARGET_PATH = Path(__file__).parent / "weapon_detect_yolov8m.pt"

if TARGET_PATH.exists():
    print(f"[OK] Weapon model already exists at: {TARGET_PATH}")
    sys.exit(0)

print("[*] Downloading keremberke/yolov8m-weapon-detection from Hugging Face...")
print("[*] Model detects: Knife, Pistol, Rifle, Shotgun, SMG")

try:
    from huggingface_hub import hf_hub_download
    path = hf_hub_download(
        repo_id="keremberke/yolov8m-weapon-detection",
        filename="best.pt",
        local_dir=str(Path(__file__).parent),
    )
    # Rename to our expected filename
    import shutil
    shutil.move(path, str(TARGET_PATH))
    print(f"[OK] Saved weapon model → {TARGET_PATH}")
except Exception as e:
    print(f"[FAIL] Could not download from Hugging Face: {e}")
    print("[*] Trying alternative: downloading via ultralytics hub...")
    try:
        from ultralytics import YOLO
        model = YOLO("keremberke/yolov8m-weapon-detection")
        print(f"[OK] Loaded via ultralytics hub: {model}")
    except Exception as e2:
        print(f"[FAIL] Alternative also failed: {e2}")
        sys.exit(1)
