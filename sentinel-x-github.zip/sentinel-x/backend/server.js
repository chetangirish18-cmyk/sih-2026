/**
 * SENTINEL-X Backend Server (Node.js / Express fallback server)
 * Cross-Source Incident Intelligence Platform (SIH 2025 - MHA / NSG)
 */

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 8000;
const MOCK_DIR = path.join(__dirname, 'app', 'mock_data');

function readJson(filename) {
    try {
        const filePath = path.join(MOCK_DIR, filename);
        if (fs.existsSync(filePath)) {
            return JSON.parse(fs.readFileSync(filePath, 'utf8'));
        }
    } catch (e) {
        console.error(`Error reading ${filename}:`, e);
    }
    return [];
}

const server = http.createServer((req, res) => {
    // Enable CORS
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
    }

    const url = new URL(req.url, `http://localhost:${PORT}`);

    if (url.pathname === '/api/health') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
            status: "HEALTHY",
            runtime: "Node.js Server",
            modules: {
                detect: "ONLINE (YOLOv8 Engine)",
                connect: "ONLINE (Spatial-Temporal Graph Engine)",
                report: "ONLINE (LLM Plain-Language Summarizer)",
                explainable_ai: "ONLINE (Audit Explanation Engine)"
            }
        }));
        return;
    }

    if (url.pathname === '/api/cameras') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(readJson('camera_sources.json')));
        return;
    }

    if (url.pathname === '/api/zones') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(readJson('zone_topology.json')));
        return;
    }

    if (url.pathname === '/api/incidents') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(readJson('sample_incidents.json')));
        return;
    }

    if (url.pathname.startsWith('/api/report/generate')) {
        const incidents = readJson('sample_incidents.json').incidents || [];
        const inc = incidents[0] || {};
        const events = inc.events || [];
        
        const report = {
            incident_id: inc.incident_id || "INC-2026-0828-01",
            title: inc.title || "Perimeter Breach & Restricted Area Infiltration",
            generated_at: new Date().toISOString(),
            classification: "TOP SECRET / NSG TACTICAL INTELLIGENCE",
            overall_risk_score: inc.overall_risk_score || 89,
            risk_level: "CRITICAL THREAT",
            executive_summary: "EXECUTIVE TACTICAL BRIEF: On 2026-08-28 at 02:14:10 UTC, SENTINEL-X correlated 4 sequential event detections spanning 4 operational cameras across 4 security zones (Outer Perimeter Gate -> North Courtyard -> Building Entrance -> Restricted Command Core). An unidentified male suspect (TARGET-X9) arrived via an unregistered SUV, dropped an unattended high-density package near HVAC infrastructure in Zone B, and executed a high-velocity sprint to bypass entry controls and force entry into Restricted Command Core (Zone D). Total elapsed incident duration: 40 seconds. Overall Threat Classification: CRITICAL (Risk Score: 89%).",
            spatial_movement_path: "Outer Perimeter Gate -> North Courtyard -> Building Entrance -> Restricted Command Core",
            chronological_narrative: events.map((e, idx) => ({
                step: idx + 1,
                timestamp: e.timestamp,
                source: `${e.camera_name} [${e.camera_type}]`,
                zone: e.zone_name,
                observation: e.explanation ? e.explanation.what : e.detection_label,
                tactical_significance: e.explanation ? e.explanation.why_abnormal : "Anomalous movement vector",
                evidence_ref: e.explanation ? e.explanation.evidence_clip_seconds : "02:14:00 - 02:14:20"
            })),
            action_recommendations: [
                "Dispatch Quick Reaction Team (QRT-1) to secure Restricted Command Core (Zone D).",
                "Deploy Bomb Disposal Squad (BDS) to inspect unattended dropped package at HVAC pillar (Zone B).",
                "Issue immediate intercept directive for vehicle registered near Outer Gate (Zone A).",
                "Lock down Server Vault Door D-02 and preserve digital audit trail clips (EVT-101 through EVT-104)."
            ],
            evidence_clips_count: events.length,
            export_formats_available: ["PDF", "MARKDOWN", "JSON", "TACTICAL_XML"]
        };

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(report));
        return;
    }

    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: "Endpoint not found" }));
});

server.listen(PORT, () => {
    console.log(`[SENTINEL-X Backend Server] Running on http://localhost:${PORT}`);
});
